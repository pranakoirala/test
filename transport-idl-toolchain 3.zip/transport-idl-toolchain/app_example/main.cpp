// Build as-is (no protobuf/flatbuffers required):
//   g++ -std=c++20 main.cpp -o app
//
// Build with real protobuf/flatbuffers wired in:
//   g++ -std=c++20 -DAPP_HAVE_PROTOBUF -DAPP_HAVE_FLATBUFFERS \
//       main.cpp telemetry.pb.cc -lprotobuf -lflatbuffers -o app
// (after running protoc on schemas/telemetry.proto and flatc on
//  schemas/imagery.fbs to produce telemetry.pb.h/.cc and imagery_generated.h)

#include "transport.hpp"
#include "buffer.hpp"
#include "envelope.hpp"
#include "loopback_transport.hpp"

#include <cstring>
#include <iostream>

#if defined(APP_HAVE_PROTOBUF)
#include "telemetry.pb.h" // protoc-generated, from schemas/telemetry.proto
#endif

#if defined(APP_HAVE_FLATBUFFERS)
#include "imagery_generated.h" // flatc-generated, from schemas/imagery.fbs
#endif

using Transport::ITransport;
using Transport::Status;
using App::HeapBuffer;
using App::MessageKind;
using App::ViewBuffer;
using App::make_tagged_buffer;

// -----------------------------------------------------------------
// 1. Protobuf: SerializeToString always copies, so this is naturally
//    a HeapBuffer -- there's no zero-copy path with protobuf's C++ API.
// -----------------------------------------------------------------
void send_protobuf_message(ITransport& transport) {
#if defined(APP_HAVE_PROTOBUF)
    Telemetry::SensorReading msg;
    msg.set_timestamp(1234.5);
    msg.set_value(98.6f);
    msg.set_unit("celsius");

    std::string bytes;
    msg.SerializeToString(&bytes);
    HeapBuffer payload(bytes.data(), bytes.size());

    auto framed = make_tagged_buffer(MessageKind::Protobuf_SensorReading, payload.data());
    if (transport.send(framed) != Status::Success) {
        std::cerr << "send failed (protobuf)\n";
    }
#else
    std::cout << "[skip] protobuf headers not available in this build\n";
#endif
}

// -----------------------------------------------------------------
// 2. FlatBuffers: the builder already owns a finished, contiguous byte
//    range -- wrap it directly with ViewBuffer instead of copying into
//    a HeapBuffer. This is the whole reason ViewBuffer exists.
// -----------------------------------------------------------------
void send_flatbuffer_message(ITransport& transport) {
#if defined(APP_HAVE_FLATBUFFERS)
    flatbuffers::FlatBufferBuilder builder;
    auto frame = Imagery::CreateFrame(builder, /* width */ 640, /* height */ 480);
    builder.Finish(frame);

    ViewBuffer payload(builder.GetBufferPointer(), builder.GetSize());

    auto framed = make_tagged_buffer(MessageKind::FlatBuffers_ImageFrame, payload.data());
    if (transport.send(framed) != Status::Success) {
        std::cerr << "send failed (flatbuffers)\n";
    }
#else
    std::cout << "[skip] flatbuffers headers not available in this build\n";
#endif
}

// -----------------------------------------------------------------
// 3. Fully custom message: no schema compiler at all, just a POD
//    struct and a memcpy. This is the "@wire_format(custom)" case --
//    idlc never sees this type; it's entirely app-owned.
// -----------------------------------------------------------------
struct LidarPoint {
    float x, y, z;
    float intensity;
};

void send_custom_message(ITransport& transport) {
    LidarPoint point{1.0f, 2.0f, 3.0f, 0.87f};
    HeapBuffer payload(&point, sizeof(point));

    auto framed = make_tagged_buffer(MessageKind::Custom_LidarPoint, payload.data());
    if (transport.send(framed) != Status::Success) {
        std::cerr << "send failed (custom)\n";
    }
}

// -----------------------------------------------------------------
// Receive side, symmetric with the tagging scheme in envelope.hpp.
// Not part of transport.idl -- purely app convention.
// -----------------------------------------------------------------
void recv_and_dispatch(ITransport& transport, std::size_t wire_size) {
    std::vector<std::uint8_t> raw(wire_size);
    HeapBuffer scratch(std::move(raw));
    if (transport.recv(scratch) != Status::Success) {
        std::cerr << "recv failed or empty\n";
        return;
    }
    switch (App::peek_kind(scratch)) {
        case MessageKind::Protobuf_SensorReading:
            std::cout << "recv: protobuf SensorReading ("
                      << App::payload_of(scratch).size() << " payload bytes)\n";
            // Telemetry::SensorReading msg; msg.ParseFromArray(...);
            break;
        case MessageKind::FlatBuffers_ImageFrame:
            std::cout << "recv: flatbuffers ImageFrame ("
                      << App::payload_of(scratch).size() << " payload bytes)\n";
            // auto frame = Imagery::GetFrame(App::payload_of(scratch).data());
            break;
        case MessageKind::Custom_LidarPoint: {
            auto p = App::payload_of(scratch);
            LidarPoint point{};
            std::memcpy(&point, p.data(), sizeof(point));
            std::cout << "recv: custom LidarPoint (" << point.x << ", " << point.y
                      << ", " << point.z << ")\n";
            break;
        }
    }
}

int main() {
    App::LoopbackTransport transport;

    Transport::Config config{{"endpoint", "loopback://demo"}};
    transport.configure(config);
    transport.open();

    send_protobuf_message(transport);   // no-op in this build (no protobuf headers)
    send_flatbuffer_message(transport); // no-op in this build (no flatbuffers headers)
    send_custom_message(transport);     // always runs -- no external library needed

    // Only the custom message actually made it into the loopback queue
    // in this build, since the other two are compiled out above.
    recv_and_dispatch(transport, 1 + sizeof(LidarPoint));

    transport.close();
    return 0;
}
