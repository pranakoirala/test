# Example: sending protobuf / FlatBuffers / custom messages over ITransport

Builds standalone, no external deps required:
```
g++ -std=c++20 main.cpp -o app && ./app
```

With real protobuf/flatbuffers wired in (after running protoc/flatc
against your own .proto/.fbs schemas):
```
g++ -std=c++20 -DAPP_HAVE_PROTOBUF -DAPP_HAVE_FLATBUFFERS \
    main.cpp telemetry.pb.cc -lprotobuf -lflatbuffers -o app
```

## Files
- `buffer.hpp`             - HeapBuffer (owning/copying) and ViewBuffer
                              (zero-copy) IBuffer implementations
- `envelope.hpp`           - app-level 1-byte message-type tag, NOT part
                              of transport.idl -- ITransport only ever
                              sees opaque bytes, so routing lives here
- `loopback_transport.hpp` - toy in-process ITransport so this runs
                              without real sockets
- `main.cpp`               - the three send_*_message() functions plus
                              a matching recv_and_dispatch()

## Known limitation surfaced while building this
`ITransport::recv()` has no way to report how many bytes were actually
received (no out-length param, and `IBuffer` has no `resize()`). Fine
for fixed-size framing (what `LoopbackTransport::recv()` assumes here);
worth adding before this goes on a real wire with variable-length
messages -- e.g. an out-param, or letting concrete `IBuffer` impls grow
themselves.
