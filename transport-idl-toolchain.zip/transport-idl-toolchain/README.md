# Transport IDL Toolchain

## Layout
- `transport.idl`        - source of truth
- `transport.hpp` / `.rs` / `Transport.java` / `transport.py` - generated
  (checked in for reference)
- `idlc/`
  - `tokenizer.py`       - lexer
  - `parser.py`          - recursive-descent parser -> Typed AST
                            (module/enum/struct/typedef/local interface)
  - `ast_nodes.py`       - Typed AST dataclasses
  - `semantics.py`       - backend-agnostic semantic resolution. Every
                            backend is a thin lookup table over this --
                            adding a language never requires touching
                            this file, and adding a FIELD to an
                            existing struct (or a whole new struct)
                            never requires touching ANY .py file, only
                            transport.idl. Verified live: added a
                            throwaway field to BufferHeader, regenerated
                            with zero .py edits, confirmed it compiled,
                            then reverted.
  - `cpp_gen.py` / `rust_gen.py` / `java_gen.py` / `python_gen.py` - backends
  - `templates/*.j2`      - pure layout, no semantic decisions
  - `main.py`             - CLI entry point
- `app_example/`          - fully self-contained, buildable example app

## Usage
```bash
pip install jinja2
python3 -m idlc.main transport.idl              # generate everything
python3 -m idlc.main transport.idl --lang cpp --lang rust
python3 -m idlc.main transport.idl --out-dir build/
```

## IBuffer / recv() -- resize() removed
`IBuffer` no longer has `resize()`. The problem it solved (recv()
reporting how many bytes actually arrived) is now solved by `recv()`
itself returning a `RecvResult { status, bytes_received }` struct,
closer to how POSIX `read()`/`recv()` report actual bytes via their
return value rather than mutating the buffer's own storage.

**Important**: after `recv()`, `IBuffer::header().size` is just the
buffer's storage capacity -- NOT necessarily the real received length.
Always use `RecvResult.bytes_received` for that, and slice `data()` to
it (`buffer.data().first(result.bytes_received)`), never trust the
full `data()` span as-is. Verified directly: sent a 3-byte message into
a 1024-byte scratch buffer, confirmed `bytes_received == 3` while
`header().size == 1024`.

## ITransport::create_transport() -- the static factory method
- **C++**: `static`, declared only -- proprietary code defines and
  links `ITransport::create_transport()` elsewhere. Returns an
  **owning raw pointer**; caller must `delete` it or wrap it in
  `unique_ptr`/`shared_ptr` immediately. Verified leak/UAF-clean under
  AddressSanitizer for all three ownership styles.
- **Rust**: an associated function (`where Self: Sized`), only callable
  as `ConcreteType::create_transport()`, never through `dyn ITransport`.
- **Java**: `static`, backed by `java.util.ServiceLoader`.
- **Python**: `@staticmethod @abc.abstractmethod`.

## Known per-backend gaps
- **Java**: `Config` is erased to `Map<String, String>` (no Java type
  alias exists); `@const_ref` becomes `final` (blocks reassignment
  only, not deep mutation).
- **Python**: byte views become plain `bytes`/`bytearray`, no enforced
  immutability beyond convention.
- **Rust struct derive**: structs derive `Clone`, not `Copy`, so a
  future struct with a non-Copy field (String, Vec, ...) won't break.

## Sanity checks
```bash
g++ -std=c++20 -fsyntax-only transport.hpp
rustc --edition 2021 --crate-type lib transport.rs
javac Transport.java
python3 -c "import transport"
```
