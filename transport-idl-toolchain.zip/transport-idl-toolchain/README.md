# Transport IDL Toolchain

## Layout
- `transport.idl`        - source of truth (ITransport / IBuffer contract)
- `transport.hpp`        - generated C++ output   (checked in for reference)
- `transport.rs`         - generated Rust output  (checked in for reference)
- `Transport.java`       - generated Java output  (checked in for reference)
- `transport.py`         - generated Python output(checked in for reference)
- `idlc/`
  - `tokenizer.py`       - lexer
  - `parser.py`          - recursive-descent parser -> Typed AST
  - `ast_nodes.py`       - Typed AST dataclasses
  - `semantics.py`       - backend-agnostic semantic resolution (erasure,
                            byte-view mutability, alias vs. builtin,
                            ref-vs-value). Every backend below is a thin
                            lookup table over this -- adding a language
                            never requires touching this file.
  - `cpp_gen.py`          - C++ backend
  - `rust_gen.py`         - Rust backend
  - `java_gen.py`         - Java backend
  - `python_gen.py`       - Python backend
  - `templates/*.j2`      - pure layout, no semantic decisions
  - `main.py`             - CLI entry point

## Usage
```bash
pip install jinja2

# generate everything
python3 -m idlc.main transport.idl

# generate specific backends
python3 -m idlc.main transport.idl --lang cpp --lang rust

# custom output dir
python3 -m idlc.main transport.idl --out-dir build/
```

## Adding a new language backend
1. `idlc/<lang>_gen.py`: a `<Lang>Mapper` with one method per
   `ResolvedType.kind` ("primitive", "platform_size", "byte_view", "map",
   "alias", "enum_ref", "interface_ref") -- mirror the existing backends.
2. `idlc/templates/transport.<ext>.j2`: layout only.
3. Register both in `_GENERATORS` in `main.py`.
No changes to tokenizer.py / parser.py / ast_nodes.py / semantics.py
should ever be needed just to add a language.

## Known per-backend gaps worth resolving before production use
- **Rust**: every trait method defaults to `&mut self` (documented in the
  generated file) since the IDL has no self-mutability annotation yet.
  Add one (e.g. `@const_self`) if you want real `&self` on read-only ops.
- **Java**: `Config` (a `typedef map<...>`) has no Java type-alias
  equivalent, so it's erased to `Map<String, String>` at every use site
  rather than generating a `Config` type. `@const_ref` becomes the
  `final` parameter modifier, which only blocks reassignment, not deep
  mutation -- weaker than C++'s `const T&` or Rust's `&T`.
- **Python**: byte views become plain `bytes`/`bytearray`; there is no
  enforced immutability for the "readonly" case beyond convention/typing.

## Sanity checks
```bash
g++ -std=c++20 -fsyntax-only transport.hpp
rustc --edition 2021 --crate-type lib transport.rs
javac Transport.java
python3 -c "import transport"
```
