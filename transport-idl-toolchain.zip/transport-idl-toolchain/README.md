# Transport IDL Toolchain

## Layout
- `transport.idl`        - source of truth (ITransport / IBuffer contract)
- `transport.hpp`        - generated C++ output   (checked in for reference)
- `transport.rs`         - generated Rust output  (checked in for reference)
- `Transport.java`       - generated Java output  (checked in for reference)
- `transport.py`         - generated Python output(checked in for reference)
- `idlc/`
  - `tokenizer.py`       - lexer
  - `parser.py`          - recursive-descent parser -> Typed AST
  - `ast_nodes.py`       - Typed AST dataclasses
  - `semantics.py`       - backend-agnostic semantic resolution (erasure,
                            byte-view mutability, alias vs. builtin,
                            ref-vs-value, const_self, static). Every
                            backend below is a thin lookup table over
                            this -- adding a language never requires
                            touching this file.
  - `cpp_gen.py`          - C++ backend
  - `rust_gen.py`         - Rust backend
  - `java_gen.py`         - Java backend
  - `python_gen.py`       - Python backend
  - `templates/*.j2`      - pure layout, no semantic decisions
  - `main.py`             - CLI entry point
- `app_example/`          - a fully self-contained, buildable example app
                            sending protobuf / FlatBuffers / custom
                            messages through ITransport::send()

## Usage
```bash
pip install jinja2
python3 -m idlc.main transport.idl              # generate everything
python3 -m idlc.main transport.idl --lang cpp --lang rust
python3 -m idlc.main transport.idl --out-dir build/
```

## Adding a new language backend
1. `idlc/<lang>_gen.py`: a `<Lang>Mapper` with one method per
   `ResolvedType.kind` -- mirror the existing backends.
2. `idlc/templates/transport.<ext>.j2`: layout only.
3. Register both in `_GENERATORS` in `main.py`.
No changes to tokenizer.py / parser.py / ast_nodes.py / semantics.py
should ever be needed just to add a language.

## ITransport::create_transport() -- the static factory method
Requested as part of `ITransport` itself rather than a separate
factory interface. What "static" resolves to differs per language,
since none of the four treat static/no-receiver methods the same way:

- **C++**: declared `static` in the class, no definition in the
  generated header -- the proprietary implementation defines
  `ITransport::create_transport()` in its own `.cpp` and links it in.
- **Rust**: an associated function (no `self`) with `where Self: Sized`,
  which excludes it from the vtable so `dyn ITransport` stays legal.
  Only callable as `ConcreteType::create_transport()`, never through a
  trait object.
- **Java**: static interface methods *must* have a body (Java doesn't
  allow abstract statics, and implementing classes can't override a
  static method). Generated as a `java.util.ServiceLoader` lookup, so
  the concrete implementation still isn't embedded in the generated
  file -- it's registered via `META-INF/services/transport.Transport$ITransport`.
- **Python**: `@staticmethod @abc.abstractmethod`, called through
  whichever concrete subclass provides it.

## Known per-backend gaps worth resolving before production use
- **`recv()` has no way to report bytes actually received** -- no
  out-length param, and `IBuffer` has no `resize()`. Fine for
  fixed-size framing; needs an out-param (or a resizable IBuffer)
  before it goes on a real wire with variable-length messages.
- **Java**: `Config` (a `typedef map<...>`) has no Java type-alias
  equivalent, so it's erased to `Map<String, String>` at every use site.
  `@const_ref` becomes `final`, which only blocks reassignment, not
  deep mutation.
- **Python**: byte views become plain `bytes`/`bytearray`; there is no
  enforced immutability for the "readonly" case beyond convention.

## Sanity checks
```bash
g++ -std=c++20 -fsyntax-only transport.hpp
rustc --edition 2021 --crate-type lib transport.rs
javac Transport.java
python3 -c "import transport"
```
