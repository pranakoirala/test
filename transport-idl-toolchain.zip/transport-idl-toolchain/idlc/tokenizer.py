"""Tokenizer for the Transport IDL subset.

Deliberately hand-rolled instead of pulling in a grammar library: the
language surface we actually need (module/enum/typedef/local interface/
annotations) is small and stable, so a ~100 line lexer + recursive-descent
parser is easier to own long-term than wiring up a full OMG-IDL4 grammar.
"""

from __future__ import annotations

import re
from dataclasses import dataclass


@dataclass
class Token:
    kind: str   # 'id' | 'punct' | 'string' | 'eof'
    value: str
    line: int


_TOKEN_RE = re.compile(
    r"""
      (?P<ws>\s+)
    | (?P<line_comment>//[^\n]*)
    | (?P<block_comment>/\*.*?\*/)
    | (?P<string>"(?:[^"\\]|\\.)*")
    | (?P<id>[A-Za-z_][A-Za-z0-9_]*)
    | (?P<punct>::|[{}();,<>@=])
    """,
    re.VERBOSE | re.DOTALL,
)


def tokenize(source: str) -> list[Token]:
    tokens: list[Token] = []
    line = 1
    pos = 0
    while pos < len(source):
        m = _TOKEN_RE.match(source, pos)
        if not m:
            bad = source[pos:pos + 20].splitlines()[0]
            raise SyntaxError(f"line {line}: unexpected input near {bad!r}")
        pos = m.end()
        line += m.group(0).count("\n")
        kind = m.lastgroup
        if kind in ("ws", "line_comment", "block_comment"):
            continue
        tokens.append(Token(kind, m.group(0), line))
    tokens.append(Token("eof", "", line))
    return tokens
