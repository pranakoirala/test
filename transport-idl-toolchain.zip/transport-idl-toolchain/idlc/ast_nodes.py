"""Typed AST for the Transport IDL subset."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class TypeRef:
    """A reference to a type: either a plain name (string, boolean,
    Config, IBuffer, ...) or a parameterized type (map<K,V>,
    sequence<octet>)."""
    name: str
    args: list["TypeRef"] = field(default_factory=list)

    def __str__(self) -> str:
        if not self.args:
            return self.name
        return f"{self.name}<{', '.join(str(a) for a in self.args)}>"


@dataclass
class EnumDecl:
    name: str
    values: list[str]


@dataclass
class StructField:
    type: TypeRef
    name: str


@dataclass
class StructDecl:
    name: str
    fields: list[StructField]


@dataclass
class TypedefDecl:
    name: str
    underlying: TypeRef


@dataclass
class Param:
    direction: str      # 'in' | 'inout' | 'out'
    type: TypeRef
    name: str
    annotations: list[str] = field(default_factory=list)


@dataclass
class Operation:
    name: str
    return_type: TypeRef
    params: list[Param]
    annotations: list[str] = field(default_factory=list)


@dataclass
class InterfaceDecl:
    name: str
    is_local: bool
    operations: list[Operation]


@dataclass
class AnnotationDecl:
    name: str


@dataclass
class Module:
    name: str
    enums: list[EnumDecl] = field(default_factory=list)
    structs: list[StructDecl] = field(default_factory=list)
    typedefs: list[TypedefDecl] = field(default_factory=list)
    interfaces: list[InterfaceDecl] = field(default_factory=list)


@dataclass
class TranslationUnit:
    """Top-level parse result: annotation declarations live outside any
    module; everything else nests inside the (single, for now) module."""
    annotations: list[AnnotationDecl]
    module: Module
