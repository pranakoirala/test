from __future__ import annotations

import argparse
import re
from pathlib import Path

from jinja2 import Environment, FileSystemLoader

from .cpp_gen import CppMapper
from .java_gen import JavaMapper
from .parser import parse
from .python_gen import PythonMapper
from .rust_gen import RustMapper
from .semantics import SemanticModel

_TEMPLATES_DIR = Path(__file__).parent / "templates"


def _make_env() -> Environment:
    return Environment(
        loader=FileSystemLoader(str(_TEMPLATES_DIR)),
        trim_blocks=True,
        lstrip_blocks=True,
    )


def _collapse_blank_lines(text: str, *, max_consecutive_newlines: int = 2) -> str:
    pattern = r"\n{" + str(max_consecutive_newlines + 1) + r",}"
    return re.sub(pattern, "\n" * max_consecutive_newlines, text)


def generate_cpp(model: SemanticModel, source_name: str, out_path: Path) -> None:
    mapper = CppMapper(model)
    env = _make_env()
    env.filters["cpp_param"] = mapper.cpp_param
    template = env.get_template("transport.hpp.j2")
    rendered = template.render(
        module=model.module,
        model=model,
        mapper=mapper,
        includes=mapper.required_includes(),
        source_file=source_name,
    )
    out_path.write_text(_collapse_blank_lines(rendered))


def generate_rust(model: SemanticModel, source_name: str, out_path: Path) -> None:
    mapper = RustMapper(model)
    env = _make_env()
    env.filters["rust_param"] = mapper.rust_param
    template = env.get_template("transport.rs.j2")
    rendered = template.render(
        module=model.module,
        model=model,
        mapper=mapper,
        needs_hashmap=mapper.needs_hashmap(),
        source_file=source_name,
    )
    out_path.write_text(_collapse_blank_lines(rendered))


def generate_java(model: SemanticModel, source_name: str, out_path: Path) -> None:
    mapper = JavaMapper(model)
    env = _make_env()
    env.filters["java_param"] = mapper.java_param
    env.filters["java_field_param"] = mapper.java_field_param
    template = env.get_template("transport.java.j2")
    rendered = template.render(
        module=model.module,
        model=model,
        mapper=mapper,
        imports=mapper.required_imports(),
        source_file=source_name,
    )
    out_path.write_text(_collapse_blank_lines(rendered))


def generate_python(model: SemanticModel, source_name: str, out_path: Path) -> None:
    mapper = PythonMapper(model)
    env = _make_env()
    env.filters["py_param"] = mapper.py_param
    template = env.get_template("transport.py.j2")
    rendered = template.render(
        module=model.module,
        model=model,
        mapper=mapper,
        needs_dict=mapper.needs_dict(),
        source_file=source_name,
    )
    # PEP 8: two blank lines between top-level defs.
    out_path.write_text(_collapse_blank_lines(rendered, max_consecutive_newlines=3))


_GENERATORS = {
    "cpp": (generate_cpp, "transport.hpp"),
    "rust": (generate_rust, "transport.rs"),
    "java": (generate_java, "Transport.java"),
    "python": (generate_python, "transport.py"),
}


def main() -> None:
    ap = argparse.ArgumentParser(description="Generate transport bindings from transport.idl")
    ap.add_argument("idl_path", type=Path, nargs="?", default=Path("transport.idl"))
    ap.add_argument("--lang", choices=sorted(_GENERATORS), action="append",
                     help="Backend(s) to run. Repeatable. Default: all.")
    ap.add_argument("--out-dir", type=Path, default=Path("."))
    args = ap.parse_args()

    unit = parse(args.idl_path.read_text())
    model = SemanticModel.build(unit.module)

    langs = args.lang or list(_GENERATORS)
    for lang in langs:
        generator, default_name = _GENERATORS[lang]
        out_path = args.out_dir / default_name
        generator(model, args.idl_path.name, out_path)
        print(f"generated {out_path}")


if __name__ == "__main__":
    main()
