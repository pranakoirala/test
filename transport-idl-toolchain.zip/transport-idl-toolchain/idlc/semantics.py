"""Backend-agnostic semantic resolution.

This is the layer that answers "what IS this IDL type/param, in language-
neutral terms" -- erasure of size_type, byte-view mutability, map shape,
alias vs. builtin, reference-vs-value passing. Every language backend
should be a thin lookup table over `ResolvedType.kind`, not a second copy
of these rules. That's the whole point of putting it here instead of
duplicating it inside cpp_gen.py / rust_gen.py / etc.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from .ast_nodes import InterfaceDecl, Module, Operation, Param, TypeRef

# Typedefs that carry platform-sized-integer semantics rather than being
# a real named alias in the generated output (C++ std::size_t, Rust
# usize, Java long, Python int -- no `using`/`type` alias emitted).
PLATFORM_SIZE_TYPEDEFS = {"size_type"}

_KIND_VOID = "void"
_KIND_PRIMITIVE = "primitive"
_KIND_PLATFORM_SIZE = "platform_size"
_KIND_BYTE_VIEW = "byte_view"
_KIND_MAP = "map"
_KIND_ALIAS = "alias"
_KIND_ENUM_REF = "enum_ref"
_KIND_INTERFACE_REF = "interface_ref"


@dataclass
class ResolvedType:
    kind: str
    name: str = ""                        # primitive name / enum name / interface name / alias name
    mutable: bool = False                  # byte_view only: True = mutable view
    key: "ResolvedType | None" = None      # map only
    value: "ResolvedType | None" = None    # map only


@dataclass
class ResolvedParam:
    name: str
    type: ResolvedType
    by_ref: bool = False       # emit as a reference/borrow rather than by value
    ref_mutable: bool = False  # if by_ref: mutable reference vs. const/shared reference


@dataclass
class ResolvedOperation:
    name: str
    return_type: ResolvedType
    params: list[ResolvedParam] = field(default_factory=list)
    const_self: bool = False
    static: bool = False


@dataclass
class SemanticModel:
    """Fully resolved view of a Module, ready for any backend to consume."""
    module: Module
    typedef_names: set[str]
    interface_names: set[str]
    enum_names: set[str]
    alias_typedefs: list["ResolvedAlias"]
    interfaces: list["ResolvedInterface"]

    @classmethod
    def build(cls, module: Module) -> "SemanticModel":
        typedef_names = {td.name for td in module.typedefs}
        interface_names = {i.name for i in module.interfaces}
        enum_names = {e.name for e in module.enums}
        model = cls(
            module=module,
            typedef_names=typedef_names,
            interface_names=interface_names,
            enum_names=enum_names,
            alias_typedefs=[],
            interfaces=[],
        )
        model.alias_typedefs = [
            ResolvedAlias(name=td.name, underlying=model._resolve_type(td.underlying))
            for td in module.typedefs
            if td.name not in PLATFORM_SIZE_TYPEDEFS
        ]
        model.interfaces = [
            ResolvedInterface(
                name=iface.name,
                operations=[model._resolve_operation(op) for op in iface.operations],
            )
            for iface in module.interfaces
        ]
        return model

    # -- internals -----------------------------------------------------
    def _resolve_type(self, t: TypeRef, *, view_hint: str | None = None) -> ResolvedType:
        if t.name in PLATFORM_SIZE_TYPEDEFS:
            return ResolvedType(kind=_KIND_PLATFORM_SIZE)
        if t.name == "void":
            return ResolvedType(kind=_KIND_VOID)
        if t.name in ("string", "boolean"):
            return ResolvedType(kind=_KIND_PRIMITIVE, name=t.name)
        if t.name == "sequence":
            mutable = view_hint == "mutable_view"
            return ResolvedType(kind=_KIND_BYTE_VIEW, mutable=mutable)
        if t.name == "map":
            key, value = t.args
            return ResolvedType(kind=_KIND_MAP, key=self._resolve_type(key), value=self._resolve_type(value))
        if t.name in self.enum_names:
            return ResolvedType(kind=_KIND_ENUM_REF, name=t.name)
        if t.name in self.interface_names:
            return ResolvedType(kind=_KIND_INTERFACE_REF, name=t.name)
        if t.name in self.typedef_names:
            return ResolvedType(kind=_KIND_ALIAS, name=t.name)
        raise ValueError(f"unresolvable type reference: {t}")

    def _resolve_operation(self, op: Operation) -> ResolvedOperation:
        view_hint = "readonly_view" if "readonly_view" in op.annotations else (
            "mutable_view" if "mutable_view" in op.annotations else None
        )
        return_type = self._resolve_type(op.return_type, view_hint=view_hint)
        const_ref = "const_ref" in op.annotations
        params = [self._resolve_param(p, const_ref=const_ref) for p in op.params]
        return ResolvedOperation(
            name=op.name,
            return_type=return_type,
            params=params,
            const_self="const_self" in op.annotations,
            static="static" in op.annotations,
        )

    def _resolve_param(self, p: Param, *, const_ref: bool) -> ResolvedParam:
        resolved = self._resolve_type(p.type)
        reference_worthy = resolved.kind in (_KIND_INTERFACE_REF, _KIND_ALIAS, _KIND_MAP)
        by_ref = reference_worthy and (const_ref or p.direction == "inout")
        ref_mutable = by_ref and p.direction == "inout" and not const_ref
        return ResolvedParam(name=p.name, type=resolved, by_ref=by_ref, ref_mutable=ref_mutable)


@dataclass
class ResolvedAlias:
    name: str
    underlying: ResolvedType


@dataclass
class ResolvedInterface:
    name: str
    operations: list[ResolvedOperation]
