"""Python backend: SemanticModel -> Python syntax.

The simplest of the four backends: no reference-vs-value distinction to
encode (everything is a reference already), and real type aliases exist
(`Config = Dict[str, str]`) so nothing needs erasing the way it does in
Java. Interfaces become abc.ABC + @abstractmethod.
"""

from __future__ import annotations

from dataclasses import dataclass

from .semantics import ResolvedOperation, ResolvedParam, ResolvedType, SemanticModel

_PRIMITIVE = {"string": "str", "boolean": "bool"}


@dataclass
class PythonMapper:
    model: SemanticModel

    def py_type(self, t: ResolvedType) -> str:
        if t.kind == "void":
            return "None"
        if t.kind == "platform_size":
            return "int"
        if t.kind == "fixed_uint32":
            return "int"
        if t.kind == "primitive":
            return _PRIMITIVE[t.name]
        if t.kind == "byte_view":
            return "bytearray" if t.mutable else "bytes"
        if t.kind == "map":
            return f"Dict[{self.py_type(t.key)}, {self.py_type(t.value)}]"
        if t.kind in ("alias", "enum_ref", "interface_ref", "struct_ref"):
            return t.name
        raise ValueError(f"unhandled ResolvedType kind: {t.kind}")

    def py_param(self, p: ResolvedParam) -> str:
        return f"{p.name}: {self.py_type(p.type)}"

    def py_return(self, op: ResolvedOperation) -> str:
        return self.py_type(op.return_type)

    def needs_dict(self) -> bool:
        def scan(t: ResolvedType) -> bool:
            return t.kind == "map"

        return any(scan(a.underlying) for a in self.model.alias_typedefs) or any(
            scan(op.return_type) or any(scan(p.type) for p in op.params)
            for iface in self.model.interfaces
            for op in iface.operations
        )
