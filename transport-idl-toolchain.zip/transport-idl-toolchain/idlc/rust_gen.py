"""Rust backend: SemanticModel -> Rust syntax.

Mirrors cpp_gen.py exactly in structure -- same ResolvedType.kind switch,
different spellings. That symmetry is the payoff of having pulled the
semantics out into semantics.py: adding a language is "write one of
these files", not "re-derive the erasure/view/ref rules again".
"""

from __future__ import annotations

from dataclasses import dataclass

from .semantics import ResolvedOperation, ResolvedParam, ResolvedType, SemanticModel

_PRIMITIVE = {"string": "String", "boolean": "bool"}


@dataclass
class RustMapper:
    model: SemanticModel

    def rust_type(self, t: ResolvedType, *, owned: bool = True) -> str:
        """`owned=True` is used for alias/struct-field positions where a
        borrow wouldn't make sense (e.g. the RHS of `pub type Config = ...`);
        parameter positions call rust_param() instead, which decides
        borrowing itself."""
        if t.kind == "void":
            return "()"
        if t.kind == "platform_size":
            return "usize"
        if t.kind == "fixed_uint32":
            return "u32"
        if t.kind == "primitive":
            return _PRIMITIVE[t.name]
        if t.kind == "byte_view":
            return "&mut [u8]" if t.mutable else "&[u8]"
        if t.kind == "map":
            return f"HashMap<{self.rust_type(t.key)}, {self.rust_type(t.value)}>"
        if t.kind == "alias":
            return t.name
        if t.kind == "enum_ref":
            return t.name
        if t.kind == "struct_ref":
            return t.name
        if t.kind == "interface_ref":
            # Trait objects: generated interfaces become `trait Name`,
            # referenced elsewhere as `&dyn Name` / `&mut dyn Name`.
            return f"dyn {t.name}"
        raise ValueError(f"unhandled ResolvedType kind: {t.kind}")

    def rust_param(self, p: ResolvedParam) -> str:
        base = self.rust_type(p.type)
        if p.by_ref:
            base = f"&mut {base}" if p.ref_mutable else f"&{base}"
        return f"{p.name}: {base}"

    def rust_return(self, op: ResolvedOperation) -> str:
        t = op.return_type
        if t.kind == "interface_ref":
            return f"Box<dyn {t.name}>"
        return self.rust_type(t)

    def needs_hashmap(self) -> bool:
        def scan(t: ResolvedType) -> bool:
            if t.kind == "map":
                return True
            return False

        for alias in self.model.alias_typedefs:
            if scan(alias.underlying):
                return True
        return False
