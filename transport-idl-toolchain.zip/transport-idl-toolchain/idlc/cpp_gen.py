"""C++ backend: SemanticModel -> C++ syntax.

Thin by design -- every actual semantic decision (erasure, byte-view
mutability, ref-vs-value, alias resolution) already happened in
semantics.py. This file only knows how to spell each ResolvedType kind
in C++ and which headers each spelling requires.
"""

from __future__ import annotations

from dataclasses import dataclass

from .semantics import ResolvedOperation, ResolvedParam, ResolvedType, SemanticModel

_PRIMITIVE = {"string": "std::string", "boolean": "bool"}

_BASELINE_INCLUDES = {"<memory>"}


@dataclass
class CppMapper:
    model: SemanticModel

    def cpp_type(self, t: ResolvedType) -> str:
        if t.kind == "void":
            return "void"
        if t.kind == "platform_size":
            return "std::size_t"
        if t.kind == "primitive":
            return _PRIMITIVE[t.name]
        if t.kind == "byte_view":
            inner = "std::uint8_t" if t.mutable else "const std::uint8_t"
            return f"std::span<{inner}>"
        if t.kind == "map":
            return f"std::map<{self.cpp_type(t.key)}, {self.cpp_type(t.value)}>"
        if t.kind in ("alias", "enum_ref", "interface_ref"):
            return t.name
        raise ValueError(f"unhandled ResolvedType kind: {t.kind}")

    def cpp_param(self, p: ResolvedParam) -> str:
        base = self.cpp_type(p.type)
        if p.by_ref:
            base = f"{base}&" if p.ref_mutable else f"const {base}&"
        return f"{base} {p.name}"

    def cpp_return(self, op: ResolvedOperation) -> str:
        t = op.return_type
        if t.kind == "interface_ref":
            # Raw, owning pointer -- caller takes ownership and is
            # responsible for eventually calling `delete`. Deliberately
            # not std::unique_ptr/std::shared_ptr: a raw pointer converts
            # implicitly into whichever owning type the caller actually
            # wants (`std::unique_ptr<T> up(create_transport());`,
            # `std::shared_ptr<T> sp(create_transport());`, or plain raw),
            # whereas a smart pointer return would force one specific
            # choice on every caller.
            return f"{t.name}*"
        return self.cpp_type(t)

    def required_includes(self) -> list[str]:
        needed: set[str] = set(_BASELINE_INCLUDES)

        def scan(t: ResolvedType) -> None:
            if t.kind == "platform_size":
                needed.add("<cstddef>")
            elif t.kind == "primitive" and t.name == "string":
                needed.add("<string>")
            elif t.kind == "byte_view":
                needed.add("<span>")
                needed.add("<cstdint>")
            elif t.kind == "map":
                needed.add("<map>")
                scan(t.key)
                scan(t.value)

        for alias in self.model.alias_typedefs:
            scan(alias.underlying)
        for iface in self.model.interfaces:
            for op in iface.operations:
                scan(op.return_type)
                for p in op.params:
                    scan(p.type)
        return sorted(needed, key=lambda h: h.strip("<>"))
