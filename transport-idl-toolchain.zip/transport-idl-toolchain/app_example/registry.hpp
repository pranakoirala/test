#pragma once

#include "transport.hpp"
#include "buffer.hpp"

#include <concepts>
#include <cstring>
#include <functional>
#include <span>
#include <string_view>
#include <type_traits>
#include <unordered_map>
#include <vector>

namespace App {

using TypeId = std::uint32_t;

// FNV-1a. Deterministic across processes/builds/languages as long as
// both sides use the same string name -- this is the whole contract
// for adding a new message type: pick a name, don't reuse someone
// else's. No shared enum/header to touch.
constexpr TypeId hash_name(std::string_view name) {
    std::uint32_t h = 2166136261u;
    for (unsigned char c : name) {
        h ^= c;
        h *= 16777619u;
    }
    return h;
}

// "What does T look like" concepts -- used exactly once per type, at
// registration, to auto-build that type's codec. Nothing downstream
// of registration is templated.
template <typename T>
concept ProtobufLike = requires(const T& msg, std::string& out) {
    { msg.SerializeToString(&out) } -> std::same_as<bool>;
};

template <typename T>
concept FlatBuilderLike = requires(T& builder) {
    { builder.GetBufferPointer() } -> std::convertible_to<const std::uint8_t*>;
    { builder.GetSize() } -> std::convertible_to<std::size_t>;
};

// ---------------------------------------------------------------
// MessageRegistry: TypeId -> (encode, dispatch) pair, both type-erased
// via std::function. send()/recv_and_dispatch() are the whole "runtime
// switch" -- pure lookups, no templates, no switch statement.
//
// type_id is now structured state on IBuffer itself (see buffer.hpp),
// not bytes manually prepended to the payload -- so unlike the
// previous version, encoders here only ever produce PAYLOAD bytes;
// send() sets the header via buffer.set_type_id() directly, and
// recv_and_dispatch() reads it via buffer.type_id().
// ---------------------------------------------------------------
class MessageRegistry {
public:
    static MessageRegistry& instance() {
        static MessageRegistry reg;
        return reg;
    }

    template <typename T>
    TypeId register_encoder(std::string_view name) {
        TypeId id = hash_name(name);
        if constexpr (ProtobufLike<T>) {
            encoders_[id] = [](const void* obj) {
                std::string bytes;
                static_cast<const T*>(obj)->SerializeToString(&bytes);
                return HeapBuffer(bytes.data(), bytes.size());
            };
        } else if constexpr (FlatBuilderLike<T>) {
            encoders_[id] = [](const void* obj) {
                auto& builder = *static_cast<T*>(const_cast<void*>(obj));
                return HeapBuffer(builder.GetBufferPointer(),
                                   static_cast<std::size_t>(builder.GetSize()));
            };
        } else {
            static_assert(std::is_trivially_copyable_v<T>,
                           "register_encoder<T>: T must be protobuf-like, "
                           "flatbuffers-builder-like, or trivially copyable");
            encoders_[id] = [](const void* obj) { return HeapBuffer(obj, sizeof(T)); };
        }
        return id;
    }

    template <typename T>
    TypeId register_handler(std::string_view name, std::function<void(const T&)> handler) {
        TypeId id = register_encoder<T>(name);
        dispatchers_[id] = [handler](std::span<const std::uint8_t> payload) {
            T value{};
            if constexpr (ProtobufLike<T>) {
                value.ParseFromArray(payload.data(), static_cast<int>(payload.size()));
            } else {
                static_assert(std::is_trivially_copyable_v<T>);
                std::memcpy(&value, payload.data(), sizeof(T));
            }
            handler(value);
        };
        return id;
    }

    // For flatbuffers (and anything else where "decode" isn't
    // "construct a T" but "interpret these bytes with a generated
    // accessor") -- handler gets the raw payload directly.
    TypeId register_raw_handler(std::string_view name,
                                 std::function<void(std::span<const std::uint8_t>)> handler) {
        TypeId id = hash_name(name);
        dispatchers_[id] = std::move(handler);
        return id;
    }

    Transport::Status send(Transport::ITransport& transport, TypeId id, const void* obj) const {
        auto it = encoders_.find(id);
        if (it == encoders_.end()) return Transport::Status::Failure;
        HeapBuffer payload = it->second(obj);
        payload.set_type_id(id);
        return transport.send(payload);
    }

    template <FlatBuilderLike T>
    Transport::Status send(Transport::ITransport& transport, TypeId id, T& builder) const {
        return send(transport, id, static_cast<const void*>(&builder));
    }

    // No switch statement, and no edit needed here when a new type is
    // registered -- purely a runtime lookup by whatever type_id the
    // received IBuffer carries. Payload is sliced to
    // RecvResult.bytes_received, NOT buffer.header().size (which is
    // just storage capacity, not necessarily the real received length).
    Transport::Status recv_and_dispatch(Transport::ITransport& transport, std::size_t max_payload_size) const {
        std::vector<std::uint8_t> raw(max_payload_size);
        HeapBuffer scratch(std::move(raw));
        auto result = transport.recv(scratch);
        if (result.status != Transport::Status::Success) return result.status;

        auto it = dispatchers_.find(scratch.header().type_id);
        if (it == dispatchers_.end()) return Transport::Status::Failure; // unregistered type
        it->second(scratch.data().first(result.bytes_received));
        return Transport::Status::Success;
    }

private:
    std::unordered_map<TypeId, std::function<HeapBuffer(const void*)>> encoders_;
    std::unordered_map<TypeId, std::function<void(std::span<const std::uint8_t>)>> dispatchers_;
};

} // namespace App
