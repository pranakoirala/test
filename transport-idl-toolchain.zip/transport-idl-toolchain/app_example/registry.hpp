#pragma once

#include "transport.hpp"
#include "buffer.hpp"
#include "envelope.hpp"

#include <concepts>
#include <cstring>
#include <functional>
#include <span>
#include <string_view>
#include <type_traits>
#include <unordered_map>
#include <vector>

namespace App {

// Same "what does T look like" concepts as before -- now used exactly
// once per type, at registration, to auto-build that type's codec.
// Nothing downstream of registration is templated.
template <typename T>
concept ProtobufLike = requires(const T& msg, std::string& out) {
    { msg.SerializeToString(&out) } -> std::same_as<bool>;
};

template <typename T>
concept FlatBuilderLike = requires(T& builder) {
    { builder.GetBufferPointer() } -> std::convertible_to<const std::uint8_t*>;
    { builder.GetSize() } -> std::convertible_to<std::size_t>;
};

// ---------------------------------------------------------------
// MessageRegistry: TypeId -> (encode, dispatch) pair, both type-erased
// via std::function. This is the whole "runtime switch" -- send() and
// recv_and_dispatch() below only ever look things up in these maps,
// they never know or care what concrete types are registered.
// ---------------------------------------------------------------
class MessageRegistry {
public:
    static MessageRegistry& instance() {
        static MessageRegistry reg;
        return reg;
    }

    // Registers T's encoder, keyed by hash_name(name). Concepts pick
    // the right strategy at compile time (this call site is templated);
    // the resulting std::function stored in encoders_ is not.
    template <typename T>
    TypeId register_encoder(std::string_view name) {
        TypeId id = hash_name(name);
        if constexpr (ProtobufLike<T>) {
            encoders_[id] = [](const void* obj) {
                std::string bytes;
                static_cast<const T*>(obj)->SerializeToString(&bytes);
                return HeapBuffer(bytes.data(), bytes.size());
            };
        } else if constexpr (FlatBuilderLike<T>) {
            encoders_[id] = [](const void* obj) {
                auto& builder = *static_cast<T*>(const_cast<void*>(obj));
                return HeapBuffer(builder.GetBufferPointer(),
                                   static_cast<std::size_t>(builder.GetSize()));
            };
        } else {
            static_assert(std::is_trivially_copyable_v<T>,
                           "register_encoder<T>: T must be protobuf-like, "
                           "flatbuffers-builder-like, or trivially copyable");
            encoders_[id] = [](const void* obj) { return HeapBuffer(obj, sizeof(T)); };
        }
        return id;
    }

    // Registers a handler that receives an already-decoded T. Requires
    // T to be protobuf-like or trivially copyable (see class-level note
    // on why flatbuffers uses register_raw_handler() instead).
    template <typename T>
    TypeId register_handler(std::string_view name, std::function<void(const T&)> handler) {
        TypeId id = register_encoder<T>(name);
        dispatchers_[id] = [handler](std::span<const std::uint8_t> payload) {
            T value{};
            if constexpr (ProtobufLike<T>) {
                value.ParseFromArray(payload.data(), static_cast<int>(payload.size()));
            } else {
                static_assert(std::is_trivially_copyable_v<T>);
                std::memcpy(&value, payload.data(), sizeof(T));
            }
            handler(value);
        };
        return id;
    }

    // For flatbuffers (and anything else where "decode" isn't
    // "construct a T" but "interpret these bytes with a generated
    // accessor") -- handler gets the raw payload directly.
    TypeId register_raw_handler(std::string_view name,
                                 std::function<void(std::span<const std::uint8_t>)> handler) {
        TypeId id = hash_name(name);
        dispatchers_[id] = std::move(handler);
        return id;
    }

    Transport::Status send(Transport::ITransport& transport, TypeId id, const void* obj) const {
        auto it = encoders_.find(id);
        if (it == encoders_.end()) return Transport::Status::Failure;
        HeapBuffer payload = it->second(obj);
        auto framed = make_tagged_buffer(id, payload.data());
        return transport.send(framed);
    }

    // FlatBuilderLike doesn't produce a T value to hand `send()`'s
    // `const void*` signature meaningfully across calls, so this
    // overload sends straight from the builder.
    template <FlatBuilderLike T>
    Transport::Status send(Transport::ITransport& transport, TypeId id, T& builder) const {
        return send(transport, id, static_cast<const void*>(&builder));
    }

    // No switch statement, and no edit needed here when a new type is
    // registered -- purely a runtime lookup by whatever TypeId showed
    // up on the wire.
    Transport::Status recv_and_dispatch(Transport::ITransport& transport, std::size_t max_wire_size) const {
        std::vector<std::uint8_t> raw(max_wire_size);
        HeapBuffer scratch(std::move(raw));
        auto status = transport.recv(scratch);
        if (status != Transport::Status::Success) return status;

        TypeId id = peek_type_id(scratch);
        auto it = dispatchers_.find(id);
        if (it == dispatchers_.end()) return Transport::Status::Failure; // unregistered type
        it->second(payload_of(scratch));
        return Transport::Status::Success;
    }

private:
    std::unordered_map<TypeId, std::function<HeapBuffer(const void*)>> encoders_;
    std::unordered_map<TypeId, std::function<void(std::span<const std::uint8_t>)>> dispatchers_;
};

} // namespace App
