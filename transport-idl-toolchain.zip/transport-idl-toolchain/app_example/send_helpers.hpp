#pragma once

#include "transport.hpp"
#include "buffer.hpp"
#include "envelope.hpp"

#include <concepts>
#include <cstdint>
#include <string>
#include <type_traits>

namespace App {

// "Looks like a protobuf message" -- duck-typed so this header compiles
// standalone without a real protobuf dependency. Swap the constraint
// for `std::derived_from<T, google::protobuf::MessageLite>` once real
// protobuf headers are in the build; call sites don't change either way.
template <typename T>
concept ProtobufLike = requires(const T& msg, std::string& out) {
    { msg.SerializeToString(&out) } -> std::same_as<bool>;
};

// "Looks like a flatbuffers::FlatBufferBuilder".
template <typename T>
concept FlatBuilderLike = requires(T& builder) {
    { builder.GetBufferPointer() } -> std::convertible_to<const std::uint8_t*>;
    { builder.GetSize() } -> std::convertible_to<std::size_t>;
};

// ---------------------------------------------------------------
// send_message: NOT part of ITransport. Overload resolution picks the
// right branch at compile time based on what T looks like; every
// branch bottoms out in the same non-templated virtual send(), after
// applying the same app-level tag framing from envelope.hpp so the
// receive side can still dispatch on MessageKind.
// ---------------------------------------------------------------

// Protobuf: SerializeToString always copies -> HeapBuffer.
template <ProtobufLike T>
Transport::Status send_message(Transport::ITransport& transport, MessageKind kind, const T& msg) {
    std::string bytes;
    msg.SerializeToString(&bytes);
    HeapBuffer payload(bytes.data(), bytes.size());
    auto framed = make_tagged_buffer(kind, payload.data());
    return transport.send(framed);
}

// FlatBuffers: the builder already holds a finished, contiguous
// buffer -- wrap it directly, zero-copy, instead of copying.
template <FlatBuilderLike T>
Transport::Status send_message(Transport::ITransport& transport, MessageKind kind, T& builder) {
    ViewBuffer payload(builder.GetBufferPointer(), builder.GetSize());
    auto framed = make_tagged_buffer(kind, payload.data());
    return transport.send(framed);
}

// Anything else that's trivially copyable and matches neither shape
// above: a plain POD struct, memcpy'd directly. This is the
// "@wire_format(custom)" case -- no schema compiler involved at all.
template <typename T>
    requires std::is_trivially_copyable_v<T> && (!ProtobufLike<T>) && (!FlatBuilderLike<T>)
Transport::Status send_message(Transport::ITransport& transport, MessageKind kind, const T& msg) {
    HeapBuffer payload(&msg, sizeof(msg));
    auto framed = make_tagged_buffer(kind, payload.data());
    return transport.send(framed);
}

// ---------------------------------------------------------------
// recv_message: protobuf side. `max_wire_size` exists because
// ITransport::recv() has no out-length parameter (see the known
// limitation noted elsewhere) -- you still have to know an upper
// bound for the incoming (tag byte + payload) up front.
// ---------------------------------------------------------------
template <ProtobufLike T>
Transport::Status recv_message(Transport::ITransport& transport, T& out, std::size_t max_wire_size) {
    std::vector<std::uint8_t> raw(max_wire_size);
    HeapBuffer scratch(std::move(raw));
    auto status = transport.recv(scratch);
    if (status != Transport::Status::Success) return status;
    auto payload = payload_of(scratch);
    out.ParseFromArray(payload.data(), static_cast<int>(payload.size()));
    return Transport::Status::Success;
}

// FlatBuffers deliberately has no recv_message<T>() -- a flatbuffers
// root object is just a typed view over raw bytes (e.g.
// `Imagery::GetFrame(payload_of(buffer).data())`), already zero-copy on
// the read side without needing a builder or a template at all.

} // namespace App

