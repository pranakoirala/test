# Example: RecvResult-based recv(), no resize()

Builds standalone:
```
g++ -std=c++20 main.cpp -o app && ./app
```

## Files
- `buffer.hpp`             - HeapBuffer / ViewBuffer; no resize() overrides
- `registry.hpp`           - MessageRegistry; recv_and_dispatch() slices
                              data() to RecvResult.bytes_received, never
                              trusts header().size after a recv()
- `loopback_transport.hpp` - recv() returns Transport::RecvResult,
                              never mutates the buffer's own storage
- `main.cpp`               - unchanged call sites -- the RecvResult
                              change was fully absorbed inside
                              registry.hpp

## Verified
Directly tested the exact scenario that used to leak 1024 bytes of
header padding into a 3-byte flatbuffers payload before RecvResult
existed: sent 3 bytes into a 1024-byte scratch buffer, confirmed
`RecvResult.bytes_received == 3` while `header().size == 1024`
(capacity, deliberately not the received length). Protobuf and
FlatBuffers mock round-trips both still exact. Clean under
AddressSanitizer.
