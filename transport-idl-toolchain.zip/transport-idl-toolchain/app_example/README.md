# Example: runtime message registry over ITransport

Builds standalone, no external deps required:
```
g++ -std=c++20 main.cpp -o app && ./app
```

With real protobuf/flatbuffers wired in (after running protoc/flatc
against your own .proto/.fbs schemas):
```
g++ -std=c++20 -DAPP_HAVE_PROTOBUF -DAPP_HAVE_FLATBUFFERS \
    main.cpp telemetry.pb.cc -lprotobuf -lflatbuffers -o app
```

## Files
- `buffer.hpp`             - HeapBuffer (owning) / ViewBuffer (zero-copy)
                              IBuffer implementations
- `envelope.hpp`           - TypeId = hash of a string name, replacing
                              a fixed MessageKind enum -- adding a
                              message type never requires editing a
                              shared enum, just picking a unique name
- `registry.hpp`           - MessageRegistry: register each type ONCE
                              (register_handler<T> / register_raw_handler),
                              using concepts to auto-detect protobuf-like
                              vs. flatbuffers-builder-like vs. trivially
                              copyable. send()/recv_and_dispatch() after
                              that are pure runtime lookups -- no
                              templates, no switch statement, and no
                              framework file needs editing to add a type
- `loopback_transport.hpp` - toy in-process ITransport so this runs
                              without real sockets
- `main.cpp`               - registers 2-4 message types (protobuf,
                              flatbuffers, and two plain structs -- one
                              added specifically to prove a new type
                              requires zero edits to registry.hpp/
                              envelope.hpp) and round-trips all of them

## Bugs found and fixed while actually testing this (not just written)
1. `LoopbackTransport::recv()` originally required the caller's buffer
   to be the *exact* size of the incoming message -- broke as soon as
   `recv_and_dispatch()` started using a generic upper-bound scratch
   buffer instead. Fixed by adding `IBuffer::resize()` to
   `transport.idl` (now in all 4 generated backends) and having
   `recv()` shrink the buffer to the real received length after
   copying.
2. `register_raw_handler()` (used for FlatBuffers) only registered the
   *decode* side, so `send()` for a flatbuffers-registered type had no
   encoder to look up and silently failed. Fixed by requiring FlatBuffers
   types to also call `register_encoder<BuilderType>(name)` -- this is
   inherent to FlatBuffers, not a workaround: the send-side type
   (the builder) and the receive-side "type" (raw bytes + a generated
   accessor) are genuinely different C++ types, unlike protobuf/POD
   where `register_handler<T>` covers both with one T.

Both were caught by writing and running a test against mock
protobuf/flatbuffers-shaped types (`ASSERT`-based), not by inspection --
worth keeping a similar smoke test if you extend this further.
