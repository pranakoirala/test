# Example: sending protobuf / FlatBuffers / custom messages over ITransport

Builds standalone, no external deps required:
```
g++ -std=c++20 main.cpp -o app && ./app
```

With real protobuf/flatbuffers wired in (after running protoc/flatc
against your own .proto/.fbs schemas):
```
g++ -std=c++20 -DAPP_HAVE_PROTOBUF -DAPP_HAVE_FLATBUFFERS \
    main.cpp telemetry.pb.cc -lprotobuf -lflatbuffers -o app
```

## Files
- `buffer.hpp`             - HeapBuffer (owning/copying) and ViewBuffer
                              (zero-copy) IBuffer implementations
- `envelope.hpp`           - app-level 1-byte message-type tag, NOT part
                              of transport.idl -- ITransport only ever
                              sees opaque bytes, so routing lives here
- `send_helpers.hpp`       - App::send_message()/recv_message(): free
                              function templates (NOT virtual methods --
                              C++ doesn't allow virtual templates) that
                              dispatch on T's shape via concepts:
                              ProtobufLike -> HeapBuffer (copies),
                              FlatBuilderLike -> ViewBuffer (zero-copy),
                              trivially-copyable fallback -> memcpy.
                              Every branch calls the same non-templated
                              ITransport::send(const IBuffer&).
- `loopback_transport.hpp` - toy in-process ITransport so this runs
                              without real sockets
- `main.cpp`               - three one-line send_message() calls plus
                              a matching recv_and_dispatch()

## Known limitations surfaced while building this
- `ITransport::recv()` has no way to report how many bytes were
  actually received (no out-length param, and `IBuffer` has no
  `resize()`). `recv_message<T>()` works around this by requiring a
  `max_wire_size` upper bound up front. Fine for now; worth adding a
  proper out-length or resizable IBuffer before this goes on a real
  wire with variable-length messages.
- `ITransport::create_transport()` returns an **owning raw pointer** --
  caller must `delete` it (or immediately wrap it in
  `std::unique_ptr`/`std::shared_ptr`, both accept a raw pointer
  directly). Verified leak/UAF-clean under AddressSanitizer for all
  three ownership styles.
