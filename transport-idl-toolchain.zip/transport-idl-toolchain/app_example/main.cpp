// Build as-is (no protobuf/flatbuffers required):
//   g++ -std=c++20 main.cpp -o app
//
// Build with real protobuf/flatbuffers wired in:
//   g++ -std=c++20 -DAPP_HAVE_PROTOBUF -DAPP_HAVE_FLATBUFFERS \
//       main.cpp telemetry.pb.cc -lprotobuf -lflatbuffers -o app

#include "transport.hpp"
#include "buffer.hpp"
#include "envelope.hpp"
#include "registry.hpp"
#include "loopback_transport.hpp"

#include <iostream>

#if defined(APP_HAVE_PROTOBUF)
#include "telemetry.pb.h" // protoc-generated, from schemas/telemetry.proto
#endif

#if defined(APP_HAVE_FLATBUFFERS)
#include "imagery_generated.h" // flatc-generated, from schemas/imagery.fbs
#endif

using Transport::ITransport;
using Transport::Status;
using App::MessageRegistry;

// -----------------------------------------------------------------
// A trivially-copyable "custom" message -- no schema compiler at all.
// -----------------------------------------------------------------
struct LidarPoint {
    float x, y, z;
    float intensity;
};

// -----------------------------------------------------------------
// A SECOND custom message added after the fact, to demonstrate the
// actual claim: registering it below is the ONLY change anywhere in
// this codebase. registry.hpp and envelope.hpp are untouched -- no
// enum to extend, no switch statement to add a case to.
// -----------------------------------------------------------------
struct Ack {
    std::uint32_t sequence_number;
};

void register_all_message_types() {
    auto& registry = MessageRegistry::instance();

#if defined(APP_HAVE_PROTOBUF)
    registry.register_handler<Telemetry::SensorReading>(
        "telemetry.SensorReading",
        [](const Telemetry::SensorReading& msg) {
            std::cout << "recv: SensorReading value=" << msg.value() << " unit=" << msg.unit() << "\n";
        });
#endif

#if defined(APP_HAVE_FLATBUFFERS)
    // FlatBuffers needs two registrations rather than one: the send-side
    // type is the builder, the receive-side "type" is really just raw
    // bytes interpreted by a generated accessor -- register_handler<T>
    // can't cover both with a single T the way it does for
    // protobuf/POD, since those are the same C++ type on both sides.
    registry.register_encoder<flatbuffers::FlatBufferBuilder>("imagery.Frame");
    registry.register_raw_handler(
        "imagery.Frame",
        [](std::span<const std::uint8_t> payload) {
            auto frame = Imagery::GetFrame(payload.data());
            std::cout << "recv: ImageFrame " << frame->width() << "x" << frame->height() << "\n";
        });
#endif

    registry.register_handler<LidarPoint>(
        "lidar.Point",
        [](const LidarPoint& p) {
            std::cout << "recv: LidarPoint (" << p.x << ", " << p.y << ", " << p.z << ")\n";
        });

    // The new type. Nothing above this function, nothing in
    // registry.hpp/envelope.hpp, had to change to add it.
    registry.register_handler<Ack>(
        "app.Ack",
        [](const Ack& ack) {
            std::cout << "recv: Ack seq=" << ack.sequence_number << "\n";
        });
}

int main() {
    register_all_message_types();
    auto& registry = MessageRegistry::instance();

    App::LoopbackTransport transport;
    Transport::Config config{{"endpoint", "loopback://demo"}};
    transport.configure(config);
    transport.open();

    int sent = 0;

#if defined(APP_HAVE_PROTOBUF)
    {
        Telemetry::SensorReading msg;
        msg.set_timestamp(1234.5);
        msg.set_value(98.6f);
        msg.set_unit("celsius");
        registry.send(transport, App::hash_name("telemetry.SensorReading"), &msg);
        ++sent;
    }
#endif

#if defined(APP_HAVE_FLATBUFFERS)
    {
        flatbuffers::FlatBufferBuilder builder;
        auto frame = Imagery::CreateFrame(builder, 640, 480);
        builder.Finish(frame);
        registry.send(transport, App::hash_name("imagery.Frame"), builder);
        ++sent;
    }
#endif

    {
        LidarPoint p{1.0f, 2.0f, 3.0f, 0.87f};
        registry.send(transport, App::hash_name("lidar.Point"), &p);
        ++sent;
    }
    {
        Ack ack{42};
        registry.send(transport, App::hash_name("app.Ack"), &ack);
        ++sent;
    }

    // Pure runtime dispatch, no switch statement -- each registered
    // handler fires itself.
    for (int i = 0; i < sent; ++i) {
        if (registry.recv_and_dispatch(transport, /*max_wire_size=*/1024) != Status::Success) {
            std::cerr << "recv_and_dispatch failed\n";
        }
    }

    transport.close();
    return 0;
}
