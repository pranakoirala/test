#pragma once

#include "transport.hpp"

#include <cstring>
#include <vector>

namespace App {

// -----------------------------------------------------------------
// HeapBuffer: owns its bytes. Use this whenever the payload needs to
// be copied anyway -- e.g. protobuf's SerializeToString/Array API
// hands you a copy regardless, and a hand-packed POD struct is small
// enough that copying it costs nothing.
// -----------------------------------------------------------------
class HeapBuffer final : public Transport::IBuffer {
public:
    explicit HeapBuffer(std::vector<std::uint8_t> bytes) : bytes_(std::move(bytes)) {}

    HeapBuffer(const void* src, std::size_t len)
        : bytes_(static_cast<const std::uint8_t*>(src), static_cast<const std::uint8_t*>(src) + len) {}

    std::size_t size() const override { return bytes_.size(); }

    std::span<const std::uint8_t> data() const override { return bytes_; }
    std::span<std::uint8_t> mutable_data() override { return bytes_; }

private:
    std::vector<std::uint8_t> bytes_;
};

// -----------------------------------------------------------------
// ViewBuffer: does NOT own its bytes -- just wraps an existing
// contiguous range. Use this for the zero-copy path, e.g. a
// FlatBufferBuilder's internal buffer, or a POD struct sitting in
// stack/heap memory you don't want to duplicate.
//
// Caller must ensure the referenced memory outlives the ViewBuffer
// (and every send() call that uses it) -- there's no lifetime
// enforcement here, exactly like std::span itself.
// -----------------------------------------------------------------
class ViewBuffer final : public Transport::IBuffer {
public:
    ViewBuffer(const std::uint8_t* ptr, std::size_t len) : ptr_(ptr), len_(len) {}

    std::size_t size() const override { return len_; }

    std::span<const std::uint8_t> data() const override { return {ptr_, len_}; }

    std::span<std::uint8_t> mutable_data() override {
        // Only valid if the wrapped memory is genuinely mutable (e.g. a
        // recv() destination buffer). Sending never needs this path.
        return {const_cast<std::uint8_t*>(ptr_), len_};
    }

private:
    const std::uint8_t* ptr_;
    std::size_t len_;
};

} // namespace App
