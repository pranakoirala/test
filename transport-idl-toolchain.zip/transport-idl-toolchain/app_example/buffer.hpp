#pragma once

#include "transport.hpp"

#include <cstring>
#include <vector>

namespace App {

// -----------------------------------------------------------------
// HeapBuffer: owns its payload bytes, plus a type_id_ header field.
// header() bundles both into one BufferHeader value. header().size is
// the buffer's storage capacity -- after a recv(), it is NOT
// necessarily the real received length; use RecvResult.bytes_received
// for that (see registry.hpp).
// -----------------------------------------------------------------
class HeapBuffer final : public Transport::IBuffer {
public:
    explicit HeapBuffer(std::vector<std::uint8_t> bytes) : bytes_(std::move(bytes)) {}

    HeapBuffer(const void* src, std::size_t len)
        : bytes_(static_cast<const std::uint8_t*>(src), static_cast<const std::uint8_t*>(src) + len) {}

    Transport::BufferHeader header() const override { return {type_id_, bytes_.size()}; }

    Transport::Status set_type_id(std::uint32_t id) override {
        type_id_ = id;
        return Transport::Status::Success;
    }

    std::span<const std::uint8_t> data() const override { return bytes_; }
    std::span<std::uint8_t> mutable_data() override { return bytes_; }

private:
    std::uint32_t type_id_ = 0;
    std::vector<std::uint8_t> bytes_;
};

// -----------------------------------------------------------------
// ViewBuffer: does NOT own its payload bytes -- just wraps an existing
// contiguous range (still owns its own type_id_ header). Use this for
// the zero-copy path, e.g. a FlatBufferBuilder's internal buffer.
//
// Caller must ensure the referenced memory outlives the ViewBuffer
// (and every send() call that uses it) -- there's no lifetime
// enforcement here, exactly like std::span itself.
// -----------------------------------------------------------------
class ViewBuffer final : public Transport::IBuffer {
public:
    ViewBuffer(const std::uint8_t* ptr, std::size_t len) : ptr_(ptr), len_(len) {}

    Transport::BufferHeader header() const override { return {type_id_, len_}; }

    Transport::Status set_type_id(std::uint32_t id) override {
        type_id_ = id;
        return Transport::Status::Success;
    }

    std::span<const std::uint8_t> data() const override { return {ptr_, len_}; }

    std::span<std::uint8_t> mutable_data() override {
        // Only valid if the wrapped memory is genuinely mutable (e.g. a
        // recv() destination buffer). Sending never needs this path.
        return {const_cast<std::uint8_t*>(ptr_), len_};
    }

private:
    std::uint32_t type_id_ = 0;
    const std::uint8_t* ptr_;
    std::size_t len_;
};

} // namespace App
