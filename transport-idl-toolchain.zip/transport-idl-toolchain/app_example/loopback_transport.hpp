#pragma once

#include "transport.hpp"

#include <cstring>
#include <deque>
#include <vector>

namespace App {

// A trivial in-process ITransport, purely so this example builds and
// runs standalone. Swap in a real TCP/UDP/shared-memory implementation
// -- everything in main.cpp is unaware of the difference.
class LoopbackTransport final : public Transport::ITransport {
public:
    Transport::Status configure(const Transport::Config&) override {
        return Transport::Status::Success;
    }

    Transport::Status open() override {
        open_ = true;
        return Transport::Status::Success;
    }

    Transport::Status close() override {
        open_ = false;
        return Transport::Status::Success;
    }

    bool is_open() const override { return open_; }

    Transport::Status send(const Transport::IBuffer& buffer) override {
        if (!open_) return Transport::Status::Failure;
        auto view = buffer.data();
        queue_.push_back(QueuedMessage{buffer.header().type_id, std::vector<std::uint8_t>(view.begin(), view.end())});
        return Transport::Status::Success;
    }

    // Reports the real received length via RecvResult.bytes_received
    // instead of shrinking the buffer's own storage -- the buffer's
    // capacity (header().size) stays whatever the caller allocated.
    Transport::RecvResult recv(Transport::IBuffer& buffer) override {
        if (queue_.empty()) return {Transport::Status::Timeout, 0};
        auto& front = queue_.front();
        auto dst = buffer.mutable_data();
        if (dst.size() < front.payload.size()) return {Transport::Status::Failure, 0};
        std::memcpy(dst.data(), front.payload.data(), front.payload.size());
        auto status = buffer.set_type_id(front.type_id);
        std::size_t received = front.payload.size();
        queue_.pop_front();
        return {status, received};
    }

private:
    struct QueuedMessage {
        std::uint32_t type_id;
        std::vector<std::uint8_t> payload;
    };

    bool open_ = false;
    std::deque<QueuedMessage> queue_;
};

} // namespace App
