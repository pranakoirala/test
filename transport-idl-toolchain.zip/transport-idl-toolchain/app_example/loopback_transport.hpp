#pragma once

#include "transport.hpp"

#include <cstring>
#include <deque>
#include <vector>

namespace App {

// A trivial in-process ITransport, purely so this example builds and
// runs standalone. Swap in a real TCP/UDP/shared-memory implementation
// -- everything in main.cpp is unaware of the difference, which is the
// whole point of coding against ITransport rather than a concrete type.
class LoopbackTransport final : public Transport::ITransport {
public:
    Transport::Status configure(const Transport::Config&) override {
        return Transport::Status::Success;
    }

    Transport::Status open() override {
        open_ = true;
        return Transport::Status::Success;
    }

    Transport::Status close() override {
        open_ = false;
        return Transport::Status::Success;
    }

    bool is_open() const override { return open_; }

    Transport::Status send(const Transport::IBuffer& buffer) override {
        if (!open_) return Transport::Status::Failure;
        auto view = buffer.data();
        queue_.emplace_back(view.begin(), view.end());
        return Transport::Status::Success;
    }

    // NOTE: this only works because the loopback queue already knows
    // each message's exact length. A real transport has no way to
    // report "N bytes actually received" back through this interface
    // -- recv() has no out-length parameter, and IBuffer has no
    // resize(). Fine for fixed-size framing; worth revisiting before
    // this goes on a real wire with variable-length messages.
    Transport::Status recv(Transport::IBuffer& buffer) override {
        if (queue_.empty()) return Transport::Status::Timeout;
        auto& front = queue_.front();
        auto dst = buffer.mutable_data();
        if (dst.size() != front.size()) return Transport::Status::Failure;
        std::memcpy(dst.data(), front.data(), front.size());
        queue_.pop_front();
        return Transport::Status::Success;
    }

private:
    bool open_ = false;
    std::deque<std::vector<std::uint8_t>> queue_;
};

} // namespace App
