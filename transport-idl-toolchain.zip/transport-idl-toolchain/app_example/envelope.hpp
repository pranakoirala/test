#pragma once

#include "buffer.hpp"

#include <cstdint>
#include <span>
#include <vector>

namespace App {

// This enum and make_tagged_buffer() are NOT generated from
// transport.idl -- ITransport/IBuffer only ever see opaque bytes, by
// design. Something still has to tell recv() which concrete type to
// decode into, so each app defines its own tiny scheme for that. This
// is the simplest one: a single leading tag byte.
enum class MessageKind : std::uint8_t {
    Protobuf_SensorReading = 1,
    FlatBuffers_ImageFrame = 2,
    Custom_LidarPoint = 3,
};

inline HeapBuffer make_tagged_buffer(MessageKind kind, std::span<const std::uint8_t> payload) {
    std::vector<std::uint8_t> bytes;
    bytes.reserve(1 + payload.size());
    bytes.push_back(static_cast<std::uint8_t>(kind));
    bytes.insert(bytes.end(), payload.begin(), payload.end());
    return HeapBuffer(std::move(bytes));
}

// Peeks the tag without consuming the buffer -- recv() dispatch uses this.
inline MessageKind peek_kind(const Transport::IBuffer& buffer) {
    return static_cast<MessageKind>(buffer.data()[0]);
}

inline std::span<const std::uint8_t> payload_of(const Transport::IBuffer& buffer) {
    return buffer.data().subspan(1);
}

} // namespace App
