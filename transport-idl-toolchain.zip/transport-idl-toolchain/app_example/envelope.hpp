#pragma once

#include "buffer.hpp"

#include <cstdint>
#include <span>
#include <string_view>
#include <vector>

namespace App {

// Replaces the old fixed MessageKind enum. A TypeId is just a hash of
// a string name the message type picks for itself -- no shared
// enum/header that every new message type has to be added to, and no
// coordination needed between teams beyond "don't reuse someone
// else's name". 32 bits keeps the framing overhead small (4 bytes vs.
// the old 1) while making accidental collisions vanishingly unlikely
// for any realistic number of registered types.
using TypeId = std::uint32_t;

// FNV-1a. Deterministic across processes/builds/languages as long as
// both sides use the same string name -- this is the actual contract
// now, instead of synchronized enum values.
constexpr TypeId hash_name(std::string_view name) {
    std::uint32_t h = 2166136261u;
    for (unsigned char c : name) {
        h ^= c;
        h *= 16777619u;
    }
    return h;
}

inline HeapBuffer make_tagged_buffer(TypeId id, std::span<const std::uint8_t> payload) {
    std::vector<std::uint8_t> bytes;
    bytes.reserve(4 + payload.size());
    for (int i = 0; i < 4; ++i) bytes.push_back(static_cast<std::uint8_t>(id >> (8 * i)));
    bytes.insert(bytes.end(), payload.begin(), payload.end());
    return HeapBuffer(std::move(bytes));
}

inline TypeId peek_type_id(const Transport::IBuffer& buffer) {
    auto d = buffer.data();
    TypeId id = 0;
    for (int i = 0; i < 4; ++i) id |= static_cast<TypeId>(d[i]) << (8 * i);
    return id;
}

inline std::span<const std::uint8_t> payload_of(const Transport::IBuffer& buffer) {
    return buffer.data().subspan(4);
}

} // namespace App
