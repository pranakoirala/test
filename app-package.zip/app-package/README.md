# App package: send/recv messages in C++, Rust, Java, and Python

For app developers sending/receiving messages over whatever `ITransport`
a separate implementor package provides. Not for implementing a
transport backend — see the `implementor-package` for that (different
audience, different, smaller file set).

## The two-layer split, in every language
1. **Mandatory, generated, always available**: `ITransport::send(const IBuffer&)` /
   `recv(IBuffer&)`. This is the whole contract; nothing else is
   required. An app can always construct a buffer directly and call
   these.
2. **Optional sugar, hand-written per language, NOT generated**: a
   `send(transport, value)`/`recv(transport, ...)` pair that derives
   encoding from the value's type and tags/checks the message's
   `type_id` automatically. This exists because `send<T>()` has to be
   a template/generic, and a virtual/trait method can't be one (the
   dispatch mechanism needs to be fixed at compile time; templates are
   instantiated per call site — fundamentally incompatible). So this
   layer can't live in the generated interface in any of the four
   languages, and it looks different in each one, because each
   language's answer to "how do I write a generic function over an
   unknown message type" is different:
   - **C++** (`src/`): concepts (`ProtobufLike`, `HasKnownName`) —
     duck-typed, detected structurally, no base class required.
   - **Rust** (`src-rust/`): a `Message` trait with an associated
     `const NAME`, implemented explicitly per type — more idiomatic
     than trying to duck-type in a language with no structural typing.
   - **Java** (`src-java/`): a `Message` interface, but `recv()` needs
     the type's name and a decoder passed explicitly — type erasure
     means there's no way to reach a "static NAME" through a generic
     type parameter the way Rust or Python can.
   - **Python** (`src-python/`): fully duck-typed via `typing.Protocol`,
     the simplest of the four — no base class, no trait, and
     `mutable_data()` can be a naturally-resizable `bytearray` instead
     of a fixed-capacity slice, so there's less to design around than
     in C++/Rust.

## Verification status — read this before trusting anything below
- **C++**: fully built and run in this environment. Every claim in
  this README about the C++ layer was actually compiled and executed,
  most of it under AddressSanitizer.
- **Python**: fully built and run in this environment (`python3` is
  available here). `src-python/test_example.py` actually passes.
- **Rust and Java**: **written carefully but NOT compiled** — neither
  `rustc` nor `javac` is available in the environment these were
  written in. Checked for brace/paren balance only, which catches
  almost nothing. Compile these yourself before trusting them; treat
  them as a careful first draft, not verified code, unlike the C++ and
  Python layers.

## Step 0: generate the interface
```bash
pip install jinja2
python3 -m idlc.main transport.idl --lang cpp      # -> transport.hpp
python3 -m idlc.main transport.idl --lang rust      # -> transport.rs
python3 -m idlc.main transport.idl --lang java      # -> Transport.java
python3 -m idlc.main transport.idl --lang python    # -> transport.py
```
For C++, CMake does this automatically as part of the build (see
`CMakeLists.txt`):
```bash
cmake -B build
cmake --build build
./build/app                # main.cpp -- always knows what it's sending/receiving
./build/registry_example   # a DIFFERENT use case -- see below
```

## Two examples, two different use cases, don't conflate them
`app` (`src/main.cpp`) never uses `MessageRegistry`
(`impl/messaging/registry.hpp`) — earlier versions of this README
described `MessageRegistry` as available without anything in the
package actually demonstrating it, which meant the claim "it works"
rested on a throwaway test file that had already been deleted, not on
anything you could verify yourself. Fixed by adding
`registry_example` (`src/registry_example.cpp`) as a real, permanent,
separately-buildable second executable:

```cpp
auto& registry = Transport::MessageRegistry::instance();
registry.register_handler<LidarPoint>("lidar.Point", [](const LidarPoint& p) { ... });
registry.register_handler<Ack>("app.Ack", [](const Ack& a) { ... });

// ... send several different message types ...

for (int i = 0; i < 3; ++i) {
    registry.recv_and_dispatch(*transport);   // no foreknowledge of which type is next
}
```

`app` always knows exactly what it's sending/receiving next (see
`main.cpp`'s `Transport::decode<LidarPoint>(scratch, result)` calls) —
it has no use for a registry. `registry_example` demonstrates the
opposite case: a server that receives messages without knowing their
type in advance, and needs `recv_and_dispatch()` to route by whatever
`type_id` shows up. Verified: routes 3 messages across 2 different
types with zero switch statements, clean under AddressSanitizer.

## A real bug that was here for a while: FlatBuffers wasn't actually zero-copy
`encode()` used to be a static method on `HeapBuffer`, returning
`HeapBuffer` unconditionally for every message type — including
FlatBuffers builders. `HeapBuffer`'s pointer constructor **copies**
into an owned `vector<uint8_t>`. So every FlatBuffers send was silently
copying the builder's buffer, defeating the entire reason to use
FlatBuffers, despite comments elsewhere explicitly (and wrongly)
claiming "zero-copy." Confirmed with a pointer-identity check —
`builder.GetBufferPointer()` and the resulting buffer's `data()`
pointer were different addresses.

Fixed by splitting `encode()` into overloads with **different return
types**: protobuf/POD get an owning `HeapBuffer` (a copy is
unavoidable for protobuf — `SerializeToString` always copies — and
cheap for small POD structs); FlatBuffers builders get a `ViewBuffer`
that points directly at the builder's own memory. Re-ran the same
pointer-identity check after the fix — same address, confirmed
genuinely zero-copy this time. This is also why `encode()`/`decode()`
are free functions now rather than methods on `HeapBuffer` specifically:
tying them to one concrete class is what caused this in the first
place, since a single method can only have one return type.

## The layout: two different kinds of "not portable"
```
src/
  main.cpp                     <- the app: #includes transport.hpp +
                                   impl/messaging/codec.hpp. NEVER
                                   references impl/transport/ directly.
  buffer.hpp                   <- HeapBuffer/ViewBuffer -- sibling of
                                   main.cpp, NOT under impl/. See below.
  impl/
    transport/
      loopback_transport.cpp   <- binary-swappable: concrete ITransport,
                                   no generics involved anywhere, so it
                                   can hide fully behind virtual dispatch.
                                   Proven, not assumed: compiled main.cpp
                                   to an object file, confirmed with `nm`
                                   that "LoopbackTransport" never appears
                                   in it, swapped which .cpp/.so gets
                                   linked, same main.o kept working.
    messaging/
      codec.hpp                <- project-level choice, NOT binary-
                                    swappable: Transport::encode<T>()
                                    is a template, generic over YOUR
                                    message types. A virtual method
                                    can't be a template (fixed vtable
                                    at compile time vs. templates
                                    instantiated per call site are
                                    incompatible) -- so this has no
                                    choice but to be compiled directly
                                    into main.cpp. A different project
                                    could write a completely different
                                    messaging/codec.hpp (protobuf-
                                    specific IBuffer, hand-rolled
                                    per-message encode/decode, ...),
                                    but THIS project's main.cpp must
                                    compile against some concrete one.
                                    #includes ../../buffer.hpp for
                                    HeapBuffer/ViewBuffer.
      registry.hpp               optional multi-type dispatch on top
```
`buffer.hpp` is a THIRD category, distinct from both subfolders above:
not binary-swappable like `transport/` (ownership semantics need
different code per language, the same reason `encode<T>()` can't be
generated — no `.so` swap fixes that), but also not really a
*project-specific* choice the way `messaging/codec.hpp`'s protobuf/
FlatBuffers detection is — "owning vs. borrowing bytes" is close to a
universal concern for any buffer type. It sits as a sibling of
`main.cpp`, outside `impl/` entirely, to reflect that it's neither
generated-portable nor a swappable implementation detail. An earlier
version had a *second*, differently-named file also called
`buffer.hpp` under `impl/messaging/` — a real naming collision, fixed
by renaming that one to `codec.hpp`, its actual content.

These two `impl/` subfolders look similar but mean genuinely different
things, and conflating them under one flat `impl/` was misleading:
`main.cpp` never touches `impl/transport/` (not even at compile time —
only the linker/loader resolves it), but it *does* directly
`#include "impl/messaging/codec.hpp"`, because it has no other choice.
That's not an inconsistency in this design; it's the same "virtual
methods can't be templates" constraint that's shown up everywhere else
in this project, just surfacing here as a directory-structure question
instead of a compile error.

## The call shape
Nothing in `main.cpp` references any concrete `ITransport`
implementation at all — not a wrapper class, not an `#include` of a
concrete header. It only ever touches `Transport::ITransport`
(generated) and `Transport::HeapBuffer` (implementation-provided, from
`impl/messaging/codec.hpp`, but living in the *same* namespace). Which concrete
transport actually runs is decided purely by which `.cpp` under
`impl/` gets linked in.

```cpp
#include "transport.hpp"
#include "impl/messaging/codec.hpp"

auto transport = std::unique_ptr<Transport::ITransport>(Transport::ITransport::create_transport());
transport->configure(config);
transport->open();

// Protobuf: SerializeToString/ParseFromArray, detected automatically.
Telemetry::SensorReading reading;
reading.set_value(98.6f);
transport->send(Transport::encode(reading));

// FlatBuffers: needs an explicit name (every schema shares the same
// C++ builder type, so nothing can infer it automatically).
flatbuffers::FlatBufferBuilder builder;
auto frame = Imagery::CreateFrame(builder, 640, 480);
builder.Finish(frame);
transport->send(Transport::encode(builder, "imagery.Frame"));

// Plain struct, no schema compiler, no registration at all:
struct LidarPoint {
    static constexpr std::string_view name = "lidar.Point";
    float x, y, z, intensity;
};
LidarPoint p{1.0f, 2.0f, 3.0f, 0.87f};
transport->send(Transport::encode(p));

Transport::HeapBuffer scratch(std::vector<std::uint8_t>(Transport::default_scratch_capacity));
auto result = transport->recv(scratch);              // the real virtual method
LidarPoint received = Transport::decode<LidarPoint>(scratch, result); // consumes its own result

transport->close();
```
No registration step for any of these. Encoding is derived entirely
from each type's shape at compile time (protobuf-like /
FlatBuffers-builder-like / trivially-copyable), so `encode()`/
`decode()` work immediately for anything with a name available via
`T::name` or an external `MessageName<T>` (via `TRANSPORT_MESSAGE_NAME`).
`HeapBuffer::raw_encode()`/`raw_decode()` (untagged) are also available
for anything building its own dispatch on top -- `registry.hpp`'s
`MessageRegistry` uses them directly.

## Genuine link-time swappability, actually proven
`src/impl/transport/loopback_transport.cpp` is a concrete `ITransport`
implementation: a `.cpp`, not a `.hpp` — the concrete class lives in
an anonymous namespace, internal linkage, invisible outside that one
file. The only externally-visible symbol it provides is
`Transport::ITransport::create_transport()`, whose *declaration*
already lives in the generated `transport.hpp`.

Proven earlier in this package's development (not re-run after
removing the second demo implementation, but the mechanism is
unchanged): compiling `main.cpp` to an object file once, linking it
against two different `impl/transport/*.cpp` files in turn, and confirming with
`nm` that neither concrete class name appears in `main.o` at all —
`md5sum main.o` identical before and after both links. That test also
caught a real bug: an earlier pass used `#include "../transport.hpp"`
inside `impl/`, which only worked in a scratch directory where
`transport.hpp` happened to sit at the parent level — the real package
generates it into `build/generated/` instead, so that relative path
was wrong; fixed to a bare `#include "transport.hpp"` relying on the
`-I` search path (as `CMakeLists.txt`'s `target_include_directories`
already sets up).

With CMake: write a second `src/impl/transport/<name>.cpp` providing
`ITransport::create_transport()`, then
`cmake -B build -DTRANSPORT_IMPL=<name>` — `src/main.cpp` is untouched
either way.

## IBuffer's header is mutable, not a setter
```cpp
buffer.mutable_header().type_id = 42;   // not buffer.set_type_id(42) -- that no longer exists
buffer.mutable_header().size = ...;
```
Mirrors the existing `data()`/`mutable_data()` split. The payoff: if
`BufferHeader` ever gains a new field, nothing needs a new setter
method — it's already writable through the same `mutable_header()`
call. `header()` returns `const BufferHeader&` (read-only view);
`mutable_header()` returns `BufferHeader&` (writable).

**`header().size` is metadata the sender sets** (typically the real
payload length at send time) — it is NOT automatically kept in sync
with a buffer's actual storage, and after a `recv()` it is NOT the
real received length. Use `RecvResult.bytes_received` for that
(returned directly by `recv()`), not `header().size`.

## Building with real protobuf/FlatBuffers
```bash
g++ -std=c++20 -DAPP_HAVE_PROTOBUF -DAPP_HAVE_FLATBUFFERS \
    src/main.cpp src/impl/transport/loopback_transport.cpp telemetry.pb.cc -lprotobuf -lflatbuffers -o app
```
(after running `protoc`/`flatc` against your own `.proto`/`.fbs`
schemas to produce `telemetry.pb.h`/`.cc` and `imagery_generated.h`).
Builds and runs standalone without either
(`g++ -std=c++20 src/main.cpp src/impl/transport/loopback_transport.cpp -o app`)
using the LidarPoint/Ack plain-struct path only — this is how
everything in this package was actually verified, since neither
library is available in the environment this was built in.

## OMG IDL 4.2 compliance
One fix verified against the actual spec text; one deliberate,
acknowledged step back from it:

- **`size_type`/`type_id_t` are fixed-width, not platform-native.**
  Real IDL's `unsigned long`/`unsigned long long` have spec-mandated
  *exact* ranges (0..2^32-1, 0..2^64-1 — Table 7-13), not "whatever
  `size_t` happens to be on this platform." `size_type` now maps to
  `std::uint64_t`/`u64`/Java `long`/Python `int` — a correctness fix
  for a wire contract meant to be portable across machines, not just a
  compliance one. Still in place.
- **`@static` is back, by request.** A compliant intermediate version
  of this existed (`ITransportFactory`, a separate interface with one
  instance operation — the standard CORBA "Factory" pattern, since
  CORBA's object model has no notion of a static/class-scoped
  operation at all). It was reverted: the app calls
  `Transport::ITransport::create_transport()` directly rather than
  constructing a factory object. `ITransport::create_transport()`
  being `static` in the generated header is something no real OMG IDL
  tool would recognize — an acknowledged tradeoff, not an oversight.

Not claimed: full compliance. The generator still supports a small,
hand-picked subset of the real grammar (module/enum/struct/typedef/
`local interface`/annotations) — most of the spec (`union`,
`valuetype`, `exception`, `attribute`, arrays, `fixed<d,s>`, `#include`,
template modules, CCM/Components building blocks) isn't implemented.
transport.idl itself, restricted to what it actually uses, should be
valid input to a real conformant IDL 4.2 parser — but `idlc` is not
that parser.

`@annotation Name { };` declaration syntax and `@name` application
syntax (no space between `@` and the name) are confirmed correct
against OMG's own IDL 4.2 issue tracker discussion of §7.4.15, which
quotes the rule text directly: "`@annotation` shall be treated as a
single token," and applying one means prefixing "with the at symbol
(@) ... no intermittent spaces, tabs, or comments." §7.4.15.4.2 also
confirms annotations "may be applied to any IDL constructs or
sub-constructs" — so applying them to operations, as this generator
does, is unrestricted, not a special case.

## Files
- `CMakeLists.txt` — generates `transport.hpp` at build time and
  builds `src/main.cpp` + whichever `.cpp` `TRANSPORT_IMPL` selects
  (default, and only, `loopback_transport`).
  `-DAPP_WITH_PROTOBUF=ON`/`-DAPP_WITH_FLATBUFFERS=ON` wire up
  `find_package`+linking+the `APP_HAVE_*` defines, but you still need
  to add your own `.proto`/`.fbs` files and their generate steps — see
  the `TODO` comments in the file. Not runnable with `cmake` in the
  environment this was built in (not installed there); verified by
  manually replicating each step's exact command instead — do a real
  `cmake -B build && cmake --build build` pass yourself before
  trusting it fully.
- `transport.idl` / `idlc/` — generate `transport.hpp` yourself (Step 0).
  Defines only the abstract `IBuffer`/`ITransport` contract — no
  concrete implementation. A `HeapBuffer` generated directly from the
  interface shape was tried and reverted: owning-byte-buffer strategy
  is an implementation choice, not something the portable contract
  should dictate. Concrete `IBuffer` implementations (generic
  byte-owning, protobuf-specific, FlatBuffers-specific, or a wrapper
  around either) are implementation-side concerns instead.
- `src/buffer.hpp` — `HeapBuffer` (owns a plain byte vector) and
  `ViewBuffer` (zero-copy, borrows memory instead of owning it), both
  hand-written, both in `namespace Transport` (reopened, not a
  separate namespace). Sibling of `main.cpp`, not under `impl/` — see
  "The layout" above for why.
- `src/impl/messaging/codec.hpp` — `#include`s `src/buffer.hpp` (one
  directory up) and adds the project-specific part:
  `Transport::encode<T>()`/`decode<T>()`, concepts (`ProtobufLike`,
  `FlatBuilderLike`), `message_name<T>()` (`T::name` inline, or
  external `MessageName<T>` via `TRANSPORT_MESSAGE_NAME` for types you
  don't own). Free functions, not methods on `HeapBuffer` — see "A
  real bug" above for why that distinction actually matters, not just
  style. `raw_encode<T>()`/`raw_decode<T>()` (untagged) are the
  building blocks `registry.hpp` uses for its own dispatch table.
  (This file used to be named `buffer.hpp` too, which was a real
  naming collision with `src/buffer.hpp` — two different files, same
  name, in different directories. Renamed to `codec.hpp`, its actual
  content, to fix that.)
- `src/impl/messaging/registry.hpp` — `MessageRegistry`, **optional**,
  only needed for a server that must route an unknown incoming type by
  whatever `type_id` shows up (`recv_and_dispatch`) — `main.cpp`
  itself never needs this. Actually demonstrated now: see
  `src/registry_example.cpp`.
- `src/registry_example.cpp` — a second, separately-buildable
  executable (`cmake --build build` produces both `app` and
  `registry_example`), demonstrating `MessageRegistry` for real —
  routing multiple different message types with no foreknowledge of
  arrival order and no switch statement.
- `src/impl/transport/loopback_transport.cpp` — toy in-process `ITransport`, a `.cpp`
  not a `.hpp`, class hidden in an anonymous namespace (not declared
  anywhere `main.cpp` can see it) so `src/main.cpp` runs standalone
  without ever referencing a concrete implementation
- `src/main.cpp` — working example; protobuf/FlatBuffers sections are
  `#if`-guarded since those libraries aren't available to test against
  here, but the plain-struct path (`LidarPoint`, `Ack`) always builds
  and runs, and is what every claim above was actually verified against
- `src-rust/buffer.rs` (core: `HeapBuffer`, `ViewBuffer<'a>` with an
  explicit lifetime), `codec.rs` (`send`/`send_view`/`recv`),
  `loopback_transport.rs`, `main.rs` — Rust equivalent. **Not compiled
  here** (see Verification status above).
- `src-java/Buffer.java` (core: nested `HeapBuffer`/`ViewBuffer`
  classes), `Codec.java` (`send`/`sendView`/`recv`),
  `LoopbackTransport.java`, `Main.java` — Java equivalent. **Not
  compiled here.** Note: `ITransport.create_transport()` goes through
  `ServiceLoader` in the generated code; `Main.java`'s example
  constructs `LoopbackTransport` directly instead, since setting up a
  real `META-INF/services` entry isn't meaningful for a self-contained
  example.
- `src-python/buffer.py` (core: `HeapBuffer`, `ViewBuffer`),
  `codec.py` (`send`/`send_view`/`recv`), `loopback_transport.py`,
  `test_example.py` — Python equivalent. **Actually run and passing**
  in this environment (`python3 src-python/test_example.py` after
  copying `transport.py` alongside it), including a `memoryview`
  identity check (`is`, not just equality) proving `send_view()` is
  genuinely zero-copy.

## The same buffer.hpp/buffer.rs/Buffer.java/buffer.py split everywhere
All four languages now separate the near-universal "own vs. borrow"
distinction (`buffer.*`, not project-specific) from format-specific
encoding (`codec.*`, project-specific), and all four have a genuine
zero-copy send path (`ViewBuffer`/`ViewBuffer<'a>`/`Buffer.ViewBuffer`/
`ViewBuffer` + `send_view`), not just C++.

This surfaced that **C++ had a real bug**: `encode()` used to return
`HeapBuffer` (owning, copying) unconditionally, including for
FlatBuffers builders — confirmed with a pointer-identity check
(`builder.GetBufferPointer()` and the resulting buffer's `data()`
pointer were different addresses). Fixed by splitting into overloads
with different return types. Re-checked after the fix — same address.
Python's equivalent check uses `is` on a `memoryview`; C++ uses raw
pointer comparison; the underlying claim (no allocation, no copy, in
the send path) is verified the same way in both, and the Rust/Java
versions were written with this already in mind from the start,
avoiding the bug entirely rather than needing a fix.
## Verified
Full round trip for a brand-new type registered nowhere
(zero-registration send/recv), a protobuf-shaped mock type via
`SerializeToString`/`ParseFromArray`, a FlatBuffers-shaped mock type
via `GetBufferPointer`/`GetSize` (exact byte count checked, no header
padding, AND a pointer-identity check confirming genuine zero-copy --
see "A real bug" above), `mutable_header()` mutation confirmed
directly, and a type-mismatch safety check (`Transport::decode<T>()`
throws on the wrong type rather than silently reinterpreting bytes).
All clean under AddressSanitizer. Link-time swappability additionally
proven with `nm`/`md5sum`, not just claimed — see above.
