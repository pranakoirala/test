// App-level message layer for Java -- optional sugar on top of the
// generated ITransport.send()/recv(). Unlike Buffer.java (near-
// universal ownership distinction), everything here IS a project-
// specific choice: how names are looked up, how types are decoded.
//
// NOT compiled in this sandbox (no javac available) -- see note in
// Buffer.java.
package transport;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.AbstractMap;
import java.util.Map;
import java.util.function.Function;

public final class Codec {
    private Codec() {}

    public static final int DEFAULT_SCRATCH_CAPACITY = 64 * 1024;

    // FNV-1a, 32-bit -- same algorithm as the C++/Rust/Python versions,
    // so a message tagged "lidar.Point" hashes to the same type_id
    // regardless of which language sent or received it.
    public static int hashName(String name) {
        int h = 0x811c9dc5;
        for (byte b : name.getBytes(StandardCharsets.UTF_8)) {
            h ^= (b & 0xFF);
            h *= 0x01000193;
        }
        return h;
    }

    public interface Message {
        String name();
        byte[] encode();
    }

    public static Transport.Status send(Transport.ITransport transport, Message value) {
        Buffer.HeapBuffer buffer = new Buffer.HeapBuffer(value.encode());
        buffer.mutable_header().type_id = hashName(value.name());
        return transport.send(buffer);
    }

    // Zero-copy: `bytes` is expected to be a real ByteBuffer VIEW --
    // e.g. a FlatBufferBuilder's dataBuffer(), not sizedByteArray()
    // (which copies -- see the note in Buffer.java). No array
    // extraction happens here at all.
    public static Transport.Status sendView(Transport.ITransport transport, ByteBuffer bytes, String name) {
        Buffer.ViewBuffer buffer = new Buffer.ViewBuffer(bytes);
        buffer.mutable_header().type_id = hashName(name);
        return transport.send(buffer);
    }

    // Java's type erasure means there's no T.NAME the way Rust has an
    // associated const, or cls.name the way Python reaches a class
    // attribute through a type object -- name and decoder must be
    // passed explicitly here. A real, honest per-language wrinkle, not
    // hidden.
    public static <T> Map.Entry<Transport.Status, T> recv(
            Transport.ITransport transport, String name, Function<byte[], T> decoder, int scratchCapacity) {
        Buffer.HeapBuffer scratch = new Buffer.HeapBuffer(scratchCapacity);
        Transport.RecvResult result = transport.recv(scratch);
        if (result.status != Transport.Status.Success) {
            return new AbstractMap.SimpleEntry<>(result.status, null);
        }
        if (scratch.header().type_id != hashName(name)) {
            return new AbstractMap.SimpleEntry<>(Transport.Status.Failure, null); // wrong type arrived
        }
        byte[] payload = new byte[(int) result.bytes_received];
        scratch.data().get(payload);
        return new AbstractMap.SimpleEntry<>(Transport.Status.Success, decoder.apply(payload));
    }

    public static <T> Map.Entry<Transport.Status, T> recv(
            Transport.ITransport transport, String name, Function<byte[], T> decoder) {
        return recv(transport, name, decoder, DEFAULT_SCRATCH_CAPACITY);
    }
}
