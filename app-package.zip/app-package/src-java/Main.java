// Demonstrates both layers: the mandatory raw ITransport.send()/recv(),
// and the optional Codec.send()/recv() sugar on top.
// NOT compiled in this sandbox -- see note in Buffer.java.
package transport;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Map;

public final class Main {

    // Mandatory minimum: construct the transport, then ->send()/->recv()
    // with a raw IBuffer. No Codec.java involved at all.
    // (Real create_transport() goes through ServiceLoader -- see the
    // note in LoopbackTransport.java. Constructing directly here keeps
    // this example self-contained.)
    static void testMandatoryMinimum() {
        Transport.ITransport transport = new LoopbackTransport();
        transport.open();

        byte[] payload = "hello".getBytes(StandardCharsets.UTF_8);
        Buffer.HeapBuffer buf = new Buffer.HeapBuffer(payload);
        buf.mutable_header().type_id = 42;
        assert transport.send(buf) == Transport.Status.Success;

        Buffer.HeapBuffer scratch = new Buffer.HeapBuffer(1024);
        Transport.RecvResult result = transport.recv(scratch);
        assert result.status == Transport.Status.Success;
        assert result.bytes_received == 5;
        assert scratch.header().type_id == 42;
        System.out.println("mandatory minimum (raw send/recv, no Codec.java) OK");
    }

    static final class Sensor implements Codec.Message {
        static final String NAME = "test.Sensor";
        final double reading;

        Sensor(double reading) { this.reading = reading; }

        @Override public String name() { return NAME; }

        @Override public byte[] encode() { return Double.toString(reading).getBytes(StandardCharsets.UTF_8); }

        static Sensor decode(byte[] bytes) {
            return new Sensor(Double.parseDouble(new String(bytes, StandardCharsets.UTF_8)));
        }
    }

    static void testOptionalSugar() {
        Transport.ITransport transport = new LoopbackTransport();
        transport.open();

        Sensor s = new Sensor(42.5);
        assert Codec.send(transport, s) == Transport.Status.Success;

        Map.Entry<Transport.Status, Sensor> result = Codec.recv(transport, Sensor.NAME, Sensor::decode);
        assert result.getKey() == Transport.Status.Success;
        assert result.getValue().reading == 42.5;
        System.out.println("optional sugar (Codec.send/Codec.recv) OK -> reading=" + result.getValue().reading);

        // Type-mismatch safety.
        Codec.send(transport, new Sensor(1.0));
        Map.Entry<Transport.Status, String> wrong = Codec.recv(transport, "test.Wrong", b -> new String(b, StandardCharsets.UTF_8));
        assert wrong.getKey() == Transport.Status.Failure;
        System.out.println("type-mismatch correctly rejected");
    }

    // Zero-copy: sendView() wraps an existing ByteBuffer directly --
    // no byte[] extraction anywhere. In a real build, `builder.dataBuffer()`
    // (NOT builder.sizedByteArray(), which copies -- see Buffer.java)
    // would be the real FlatBuffers zero-copy accessor passed here.
    static void testZeroCopySend() {
        Transport.ITransport transport = new LoopbackTransport();
        transport.open();

        byte[] backing = {10, 20, 30};
        ByteBuffer builderView = ByteBuffer.wrap(backing); // stand-in for builder.dataBuffer()
        assert Codec.sendView(transport, builderView, "fake.FlatBuffer") == Transport.Status.Success;

        Buffer.HeapBuffer scratch = new Buffer.HeapBuffer(1024);
        Transport.RecvResult result = transport.recv(scratch);
        assert result.status == Transport.Status.Success;
        assert result.bytes_received == 3;
        System.out.println("zero-copy sendView() OK -- exact byte match, no byte[] extraction in the send path");
    }

    public static void main(String[] args) {
        testMandatoryMinimum();
        testOptionalSugar();
        testZeroCopySend();
        System.out.println("\nAll Java layer tests passed (structurally -- not compiled in this sandbox).");
    }
}
