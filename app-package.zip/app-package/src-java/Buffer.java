// Core: HeapBuffer (owning) and ViewBuffer (borrowing). Hand-written,
// not generated -- "owning vs. borrowing" needs different code per
// language (Rust needs an explicit lifetime parameter; Java has no
// such concept, but ByteBuffer's duplicate()/wrap() semantics give a
// natural non-copying "view" already), but the CONCEPT is near-
// universal, unlike message-encoding strategy (Codec.java), which is
// project-specific.
//
// NOT compiled in this sandbox (no javac available) -- treat as a
// careful draft, not verified code.
package transport;

import java.nio.ByteBuffer;

public final class Buffer {
    private Buffer() {}

    public static final class HeapBuffer implements Transport.IBuffer {
        private Transport.BufferHeader header;
        private ByteBuffer buf;

        public HeapBuffer(byte[] data) {
            this.header = new Transport.BufferHeader(0, data.length);
            this.buf = ByteBuffer.wrap(data); // does not copy `data` -- wraps the existing array
        }

        public HeapBuffer(int capacity) {
            this.header = new Transport.BufferHeader(0, capacity);
            this.buf = ByteBuffer.allocate(capacity);
        }

        @Override
        public Transport.BufferHeader header() { return header; }

        @Override
        public Transport.BufferHeader mutable_header() { return header; }

        @Override
        public ByteBuffer data() { return buf.duplicate(); } // fresh view each call, no copy

        @Override
        public ByteBuffer mutable_data() { return buf.duplicate(); }
    }

    // Wraps an EXISTING ByteBuffer directly -- no byte[] extraction
    // anywhere, which is what makes this genuinely zero-copy. The real
    // FlatBuffers Java API's zero-copy accessor is
    // FlatBufferBuilder.dataBuffer() (a ByteBuffer view into the
    // builder's own backing array); its sizedByteArray() method, by
    // contrast, DOES copy internally -- FlatBuffers builds backwards
    // from the buffer's end, so producing a correctly-sized byte[]
    // requires copying out of the middle of a larger backing array.
    // Use dataBuffer() with this class, not sizedByteArray().
    public static final class ViewBuffer implements Transport.IBuffer {
        private Transport.BufferHeader header;
        private final ByteBuffer buf;

        public ViewBuffer(ByteBuffer bytes) {
            this.header = new Transport.BufferHeader(0, bytes.remaining());
            this.buf = bytes;
        }

        @Override
        public Transport.BufferHeader header() { return header; }

        @Override
        public Transport.BufferHeader mutable_header() { return header; }

        @Override
        public ByteBuffer data() { return buf.duplicate(); }

        @Override
        public ByteBuffer mutable_data() {
            throw new UnsupportedOperationException(
                "ViewBuffer is read-only (send-only zero-copy view) -- use HeapBuffer for recv()");
        }
    }
}
