// Toy in-process ITransport, purely so examples run standalone. NOT
// compiled in this sandbox -- see note in Buffer.java.
package transport;

import java.nio.ByteBuffer;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Map;

public final class LoopbackTransport implements Transport.ITransport {
    private boolean open = false;
    private final Deque<QueuedMessage> queue = new ArrayDeque<>();

    private static final class QueuedMessage {
        final int typeId;
        final byte[] payload;

        QueuedMessage(int typeId, byte[] payload) {
            this.typeId = typeId;
            this.payload = payload;
        }
    }

    // NOTE: Transport.ITransport.create_transport() is backed by
    // java.util.ServiceLoader in the generated code -- using it for
    // real requires registering this class in
    // META-INF/services/transport.Transport$ITransport. For a
    // self-contained example, construct directly instead:
    //   ITransport transport = new LoopbackTransport();

    @Override
    public Transport.Status configure(final Map<String, String> config) {
        return Transport.Status.Success;
    }

    @Override
    public Transport.Status open() {
        open = true;
        return Transport.Status.Success;
    }

    @Override
    public Transport.Status close() {
        open = false;
        return Transport.Status.Success;
    }

    @Override
    public boolean is_open() {
        return open;
    }

    @Override
    public Transport.Status send(final Transport.IBuffer buffer) {
        if (!open) return Transport.Status.Failure;
        ByteBuffer data = buffer.data();
        byte[] payload = new byte[data.remaining()];
        data.duplicate().get(payload);
        queue.addLast(new QueuedMessage(buffer.header().type_id, payload));
        return Transport.Status.Success;
    }

    @Override
    public Transport.RecvResult recv(Transport.IBuffer buffer) {
        QueuedMessage front = queue.pollFirst();
        if (front == null) {
            return new Transport.RecvResult(Transport.Status.Timeout, 0);
        }
        ByteBuffer dst = buffer.mutable_data();
        if (dst.remaining() < front.payload.length) {
            return new Transport.RecvResult(Transport.Status.Failure, 0);
        }
        dst.duplicate().put(front.payload);
        buffer.mutable_header().type_id = front.typeId;
        return new Transport.RecvResult(Transport.Status.Success, front.payload.length);
    }
}
