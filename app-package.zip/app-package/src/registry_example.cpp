// A DIFFERENT use case from main.cpp: a server that doesn't know what
// type is arriving next and needs to route by whatever type_id shows
// up. main.cpp never needs this -- it always knows exactly what it's
// sending/receiving. This is the actual, buildable proof that
// MessageRegistry works, not a claim -- the earlier verification of
// this lived in a throwaway probe file that got deleted, which meant
// nothing here demonstrated it. This file replaces that gap.
//
// Build:
//   g++ -std=c++20 registry_example.cpp impl/transport/loopback_transport.cpp -o registry_example

#include "transport.hpp"
#include "impl/messaging/registry.hpp"

#include <iostream>
#include <cassert>

struct LidarPoint {
    static constexpr std::string_view name = "lidar.Point";
    float x, y, z;
};

struct Ack {
    static constexpr std::string_view name = "app.Ack";
    std::uint32_t sequence_number;
};

int main() {
    auto& registry = Transport::MessageRegistry::instance();

    // Register handlers for each type ONCE, at startup -- this is the
    // actual cost of using the registry: a registration step main.cpp
    // never needs, in exchange for not needing to know incoming types
    // in advance.
    int lidar_count = 0;
    registry.register_handler<LidarPoint>("lidar.Point", [&](const LidarPoint& p) {
        std::cout << "handled LidarPoint (" << p.x << ", " << p.y << ", " << p.z << ")\n";
        ++lidar_count;
    });

    int ack_count = 0;
    registry.register_handler<Ack>("app.Ack", [&](const Ack& a) {
        std::cout << "handled Ack seq=" << a.sequence_number << "\n";
        ++ack_count;
    });

    auto transport = std::unique_ptr<Transport::ITransport>(Transport::ITransport::create_transport());
    transport->open();

    // Send several DIFFERENT message types.
    LidarPoint p1{1.0f, 2.0f, 3.0f};
    Ack a1{42};
    LidarPoint p2{4.0f, 5.0f, 6.0f};
    registry.send(*transport, Transport::hash_name("lidar.Point"), &p1);
    registry.send(*transport, Transport::hash_name("app.Ack"), &a1);
    registry.send(*transport, Transport::hash_name("lidar.Point"), &p2);

    // Receive them WITHOUT knowing in advance which type is next --
    // this is the actual point of the registry. recv_and_dispatch()
    // looks up whatever type_id arrived and calls the matching
    // handler above; nothing here branches on message type.
    for (int i = 0; i < 3; ++i) {
        auto status = registry.recv_and_dispatch(*transport);
        assert(status == Transport::Status::Success);
    }

    assert(lidar_count == 2);
    assert(ack_count == 1);

    std::cout << "\nMessageRegistry verified: routed 3 messages of 2 different types "
                 "with zero switch statements and zero foreknowledge of arrival order.\n";
    return 0;
}
