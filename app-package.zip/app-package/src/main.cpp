// Build (two translation units -- the interface side and the
// implementation side are genuinely separate now):
//   g++ -std=c++20 main.cpp impl/transport/loopback_transport.cpp -o app
//
// Build with real protobuf/flatbuffers wired in:
//   g++ -std=c++20 -DAPP_HAVE_PROTOBUF -DAPP_HAVE_FLATBUFFERS \
//       main.cpp impl/transport/loopback_transport.cpp telemetry.pb.cc -lprotobuf -lflatbuffers -o app

#include "transport.hpp"
#include "impl/messaging/codec.hpp" // compile-time-fixed, unlike impl/transport/ (binary-swappable) -- see below

#include <iostream>
#include <memory>

#if defined(APP_HAVE_PROTOBUF)
#include "telemetry.pb.h" // protoc-generated, from schemas/telemetry.proto
TRANSPORT_MESSAGE_NAME(Telemetry::SensorReading, "telemetry.SensorReading");
#endif

#if defined(APP_HAVE_FLATBUFFERS)
#include "imagery_generated.h" // flatc-generated, from schemas/imagery.fbs
#endif

using Transport::Status;

// -----------------------------------------------------------------
// No base class, no external trait, no registration call needed --
// just a name declared inline.
// -----------------------------------------------------------------
struct LidarPoint {
    static constexpr std::string_view name = "lidar.Point";
    float x, y, z;
    float intensity;
};

struct Ack {
    static constexpr std::string_view name = "app.Ack";
    std::uint32_t sequence_number;
};

int main() {
    // This file never names, includes, or otherwise references any
    // concrete ITransport implementation -- only the generated
    // interface (transport.hpp) and hand-written message helpers
    // (impl/messaging/codec.hpp), both under namespace Transport. Which concrete
    // class actually runs is decided entirely by which .cpp gets
    // linked alongside this one.
    auto transport = std::unique_ptr<Transport::ITransport>(Transport::ITransport::create_transport());
    Transport::Config config{{"endpoint", "loopback://demo"}};
    transport->configure(config);
    transport->open();

    LidarPoint p{1.0f, 2.0f, 3.0f, 0.87f};
    transport->send(Transport::encode(p));

    Ack ack{42};
    transport->send(Transport::encode(ack));

#if defined(APP_HAVE_PROTOBUF)
    Telemetry::SensorReading reading;
    reading.set_timestamp(1234.5);
    reading.set_value(98.6f);
    reading.set_unit("celsius");
    transport->send(Transport::encode(reading));
#endif

#if defined(APP_HAVE_FLATBUFFERS)
    flatbuffers::FlatBufferBuilder builder;
    auto frame = Imagery::CreateFrame(builder, 640, 480);
    builder.Finish(frame);
    transport->send(Transport::encode(builder, "imagery.Frame")); // FlatBuffers needs an explicit name
#endif

    {
        Transport::HeapBuffer scratch(std::vector<std::uint8_t>(Transport::default_scratch_capacity));
        auto result = transport->recv(scratch);
        LidarPoint received = Transport::decode<LidarPoint>(scratch, result);
        std::cout << "received LidarPoint (" << received.x << ", " << received.y << ", "
                  << received.z << ")\n";
    }

    {
        Transport::HeapBuffer scratch(std::vector<std::uint8_t>(Transport::default_scratch_capacity));
        auto result = transport->recv(scratch);
        Ack received_ack = Transport::decode<Ack>(scratch, result);
        std::cout << "received Ack seq=" << received_ack.sequence_number << "\n";
    }

    transport->close();
    return 0;
}
