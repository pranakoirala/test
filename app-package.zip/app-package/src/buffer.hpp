#pragma once

#include "transport.hpp"

#include <vector>

// Reopens namespace Transport -- not a separate "App" namespace.
// HeapBuffer/ViewBuffer live here, not under impl/: unlike message
// encoding (which depends entirely on project-specific choices --
// protobuf? FlatBuffers? something else?), "owning bytes" vs.
// "borrowing bytes" is close to a universal concern for any buffer
// type, in any language. It's still hand-written, not generated
// (idlc can't generate it -- ownership semantics vary too much per
// language to have one universal answer, the same reason encode<T>()
// can't be generated), but it isn't a project-specific choice the way
// impl/messaging/'s protobuf/FlatBuffers detection is.
namespace Transport {

// -----------------------------------------------------------------
// HeapBuffer: owns its payload bytes generically (a plain
// vector<uint8_t>).
// -----------------------------------------------------------------
class HeapBuffer final : public IBuffer {
public:
    explicit HeapBuffer(std::vector<std::uint8_t> bytes)
        : header_{0, bytes.size()}, bytes_(std::move(bytes)) {}

    HeapBuffer(const void* src, std::size_t len)
        : header_{0, len},
          bytes_(static_cast<const std::uint8_t*>(src), static_cast<const std::uint8_t*>(src) + len) {}

    const BufferHeader& header() const override { return header_; }
    BufferHeader& mutable_header() override { return header_; }

    std::span<const std::uint8_t> data() const override { return bytes_; }
    std::span<std::uint8_t> mutable_data() override { return bytes_; }

private:
    BufferHeader header_;
    std::vector<std::uint8_t> bytes_;
};

// -----------------------------------------------------------------
// ViewBuffer: does NOT own its payload bytes -- wraps an existing
// contiguous range in place. What makes zero-copy encoding possible
// at all (see impl/messaging/buffer.hpp's encode() for FlatBuffers).
//
// Caller must ensure the referenced memory outlives the ViewBuffer
// (and every send() call that uses it) -- there's no lifetime
// enforcement here, exactly like std::span itself.
// -----------------------------------------------------------------
class ViewBuffer final : public IBuffer {
public:
    ViewBuffer(const std::uint8_t* ptr, std::size_t len) : header_{0, len}, ptr_(ptr), len_(len) {}

    const BufferHeader& header() const override { return header_; }
    BufferHeader& mutable_header() override { return header_; }

    std::span<const std::uint8_t> data() const override { return {ptr_, len_}; }

    std::span<std::uint8_t> mutable_data() override {
        return {const_cast<std::uint8_t*>(ptr_), len_};
    }

private:
    BufferHeader header_;
    const std::uint8_t* ptr_;
    std::size_t len_;
};

} // namespace Transport
