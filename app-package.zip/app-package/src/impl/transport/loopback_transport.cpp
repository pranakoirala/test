// A concrete ITransport implementation -- a .cpp, not a .hpp, and
// LoopbackTransport is declared nowhere else. Nothing outside this
// file ever names this class; the only externally-visible symbol is
// the out-of-line ITransport::create_transport() definition at the
// bottom, whose declaration already lives in the generated
// transport.hpp. To swap implementations: write another .cpp that
// defines the same symbol (returning a different concrete class), and
// link that one instead -- main.cpp doesn't change, doesn't even
// need recompiling, just relinking.

#include "transport.hpp"

#include <cstring>
#include <deque>
#include <vector>

namespace Transport {
namespace {

class LoopbackTransport final : public ITransport {
public:
    Status configure(const Config&) override { return Status::Success; }
    Status open() override { open_ = true; return Status::Success; }
    Status close() override { open_ = false; return Status::Success; }
    bool is_open() const override { return open_; }

    Status send(const IBuffer& buffer) override {
        if (!open_) return Status::Failure;
        auto view = buffer.data();
        queue_.push_back({buffer.header().type_id, std::vector<std::uint8_t>(view.begin(), view.end())});
        return Status::Success;
    }

    RecvResult recv(IBuffer& buffer) override {
        if (queue_.empty()) return {Status::Timeout, 0};
        auto& front = queue_.front();
        auto dst = buffer.mutable_data();
        if (dst.size() < front.payload.size()) return {Status::Failure, 0};
        std::memcpy(dst.data(), front.payload.data(), front.payload.size());
        buffer.mutable_header().type_id = front.type_id;
        std::size_t received = front.payload.size();
        queue_.pop_front();
        return {Status::Success, received};
    }

private:
    struct QueuedMessage {
        std::uint32_t type_id;
        std::vector<std::uint8_t> payload;
    };

    bool open_ = false;
    std::deque<QueuedMessage> queue_;
};

} // anonymous namespace -- internal linkage: LoopbackTransport is not
  // an exported symbol, genuinely invisible to the linker outside this TU

ITransport* ITransport::create_transport() {
    return new LoopbackTransport();
}

} // namespace Transport
