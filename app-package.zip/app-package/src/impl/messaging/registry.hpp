#pragma once

#include "transport.hpp"
#include "codec.hpp"

#include <functional>
#include <span>
#include <string_view>
#include <unordered_map>
#include <vector>

namespace Transport {

// ---------------------------------------------------------------
// MessageRegistry: for the one case HeapBuffer::encode()/decode()
// genuinely can't cover -- a server that doesn't know what type is
// arriving next and needs to route by whatever type_id shows up.
// Everything else (send, and recv when you already know the expected
// type) needs NO registration at all -- see buffer.hpp, which this
// builds on top of rather than duplicating.
// ---------------------------------------------------------------
class MessageRegistry {
public:
    static MessageRegistry& instance() {
        static MessageRegistry reg;
        return reg;
    }

    template <typename T>
    TypeId register_encoder(std::string_view name) {
        TypeId id = hash_name(name);
        encoders_[id] = [](const void* obj) { return raw_encode(*static_cast<const T*>(obj)); };
        return id;
    }

    template <typename T>
    TypeId register_handler(std::string_view name, std::function<void(const T&)> handler) {
        TypeId id = register_encoder<T>(name);
        dispatchers_[id] = [handler](std::span<const std::uint8_t> payload) {
            T value{};
            raw_decode(payload, value);
            handler(value);
        };
        return id;
    }

    // For FlatBuffers (and anything else where "decode" isn't
    // "construct a T" but "interpret these bytes with a generated
    // accessor") -- handler gets the raw payload directly.
    TypeId register_raw_handler(std::string_view name,
                                 std::function<void(std::span<const std::uint8_t>)> handler) {
        TypeId id = hash_name(name);
        dispatchers_[id] = std::move(handler);
        return id;
    }

    Status send(ITransport& transport, TypeId id, const void* obj) const {
        auto it = encoders_.find(id);
        if (it == encoders_.end()) return Status::Failure;
        HeapBuffer payload = it->second(obj);
        payload.mutable_header().type_id = id;
        return transport.send(payload);
    }

    template <FlatBuilderLike T>
    Status send(ITransport& transport, TypeId id, T& builder) const {
        return send(transport, id, static_cast<const void*>(&builder));
    }

    // Pure runtime lookup, no switch statement, no edit needed here
    // when a new type is registered. scratch_capacity has the same
    // fixed-internal-default rationale as HeapBuffer::decode().
    Status recv_and_dispatch(ITransport& transport, std::size_t scratch_capacity = default_scratch_capacity) const {
        std::vector<std::uint8_t> raw(scratch_capacity);
        HeapBuffer scratch(std::move(raw));
        auto result = transport.recv(scratch);
        if (result.status != Status::Success) return result.status;

        auto it = dispatchers_.find(scratch.header().type_id);
        if (it == dispatchers_.end()) return Status::Failure; // unregistered type
        it->second(scratch.data().first(result.bytes_received));
        return Status::Success;
    }

private:
    std::unordered_map<TypeId, std::function<HeapBuffer(const void*)>> encoders_;
    std::unordered_map<TypeId, std::function<void(std::span<const std::uint8_t>)>> dispatchers_;
};

} // namespace Transport
