#pragma once

#include "../../buffer.hpp" // HeapBuffer/ViewBuffer -- near-core, not project-specific

#include <concepts>
#include <cstring>
#include <stdexcept>
#include <string_view>
#include <type_traits>

// Reopens namespace Transport. Unlike ../../buffer.hpp (HeapBuffer/
// ViewBuffer -- an ownership distinction relevant to nearly any
// project), everything below IS a project-specific choice: detecting
// protobuf/FlatBuffers by shape, and dispatching encode()/decode()
// accordingly. A different project might not use either library at
// all, or might use a completely different detection mechanism.
namespace Transport {

using TypeId = std::uint32_t;

// FNV-1a. Deterministic across processes/builds/languages as long as
// both sides use the same string name -- the whole contract for
// adding a new message type: pick a name, don't reuse someone else's.
constexpr TypeId hash_name(std::string_view name) {
    std::uint32_t h = 2166136261u;
    for (unsigned char c : name) {
        h ^= c;
        h *= 16777619u;
    }
    return h;
}

template <typename T>
concept ProtobufLike = requires(const T& msg, std::string& out) {
    { msg.SerializeToString(&out) } -> std::same_as<bool>;
};

template <typename T>
concept FlatBuilderLike = requires(T& builder) {
    { builder.GetBufferPointer() } -> std::convertible_to<const std::uint8_t*>;
    { builder.GetSize() } -> std::convertible_to<std::size_t>;
};

template <typename T>
concept HasInlineName = requires { { T::name } -> std::convertible_to<std::string_view>; };

template <typename T>
struct MessageName; // no default; see TRANSPORT_MESSAGE_NAME below

#define TRANSPORT_MESSAGE_NAME(TYPE, NAME)                                   \
    template <>                                                             \
    struct Transport::MessageName<TYPE> {                                   \
        static constexpr std::string_view value = NAME;                    \
    }

template <typename T>
concept HasKnownName = HasInlineName<T> || requires { MessageName<T>::value; };

template <HasKnownName T>
constexpr std::string_view message_name() {
    if constexpr (HasInlineName<T>) {
        return T::name;
    } else {
        return MessageName<T>::value;
    }
}

constexpr std::size_t default_scratch_capacity = 64 * 1024;

// -----------------------------------------------------------------
// Encoding/decoding: free functions, NOT tied to one concrete buffer
// type -- this matters, not just for style. An earlier version tied
// encode() to HeapBuffer specifically and returned HeapBuffer
// unconditionally, including for FlatBuffers builders -- silently
// COPYING every FlatBuffers message (verified with a pointer-identity
// check at the time: the copy's address never matched the builder's
// own buffer address), completely defeating the reason to use
// FlatBuffers at all. Splitting into overloads with different return
// types fixes it: protobuf/POD get an owning HeapBuffer; FlatBuffers
// builders get a ViewBuffer that points directly at the builder's own
// memory -- genuinely zero-copy, verified with the same pointer check.
//
// decode() takes `const IBuffer&` generically rather than being tied
// to HeapBuffer specifically -- the closest equivalent to "on IBuffer"
// that's actually possible: IBuffer itself can't have template
// methods, so a free function taking the abstract interface as its
// operand is the practical substitute. Works identically whether the
// buffer handed to it is a HeapBuffer or a ViewBuffer.
// -----------------------------------------------------------------

// ProtobufLike or trivially-copyable POD -> owns a copy in HeapBuffer.
template <typename T>
    requires HasKnownName<T> && (ProtobufLike<T> || (std::is_trivially_copyable_v<T> && !FlatBuilderLike<T>))
HeapBuffer encode(const T& value) {
    HeapBuffer buffer = [&] {
        if constexpr (ProtobufLike<T>) {
            std::string bytes;
            value.SerializeToString(&bytes);
            return HeapBuffer(bytes.data(), bytes.size());
        } else {
            return HeapBuffer(&value, sizeof(T));
        }
    }();
    buffer.mutable_header().type_id = hash_name(message_name<T>());
    return buffer;
}

// FlatBuffers builder -> ViewBuffer, genuinely zero-copy: points
// directly at the builder's own internal buffer. FlatBuffers builders
// can't carry a compile-time name (every schema shares the same C++
// builder type), so the name is an explicit argument.
template <FlatBuilderLike T>
ViewBuffer encode(T& builder, std::string_view name) {
    ViewBuffer buffer(builder.GetBufferPointer(), static_cast<std::size_t>(builder.GetSize()));
    buffer.mutable_header().type_id = hash_name(name);
    return buffer;
}

// Untagged encode -- used by encode() above and by MessageRegistry
// (registry.hpp), which tags separately for its own dispatch table.
template <typename T>
HeapBuffer raw_encode(const T& value) {
    if constexpr (ProtobufLike<T>) {
        std::string bytes;
        value.SerializeToString(&bytes);
        return HeapBuffer(bytes.data(), bytes.size());
    } else {
        static_assert(std::is_trivially_copyable_v<T> && !FlatBuilderLike<T>,
                       "raw_encode<T>: T must be protobuf-like or trivially copyable "
                       "(FlatBuffers builders need the zero-copy encode() overload above, "
                       "not raw_encode -- there's no owning-copy equivalent for them here "
                       "on purpose)");
        return HeapBuffer(&value, sizeof(T));
    }
}

template <typename T>
void raw_decode(std::span<const std::uint8_t> payload, T& out) {
    if constexpr (ProtobufLike<T>) {
        out.ParseFromArray(payload.data(), static_cast<int>(payload.size()));
    } else {
        static_assert(std::is_trivially_copyable_v<T>,
                       "raw_decode<T>: T must be protobuf-like or trivially copyable "
                       "(FlatBuffers types don't decode into an existing T -- interpret "
                       "the raw payload with a generated accessor instead)");
        std::memcpy(&out, payload.data(), sizeof(T));
    }
}

// Consumes whatever ITransport::recv() -- the real, unmodified virtual
// method -- already filled into `buffer`, and decodes it into T.
// Works with any concrete IBuffer, not just HeapBuffer. Throws on
// failure/type-mismatch (returns T by value, no Status slot available).
template <HasKnownName T>
T decode(const IBuffer& buffer, const RecvResult& result) {
    if (result.status != Status::Success) {
        throw std::runtime_error("Transport::decode<T>: recv() did not succeed");
    }
    if (buffer.header().type_id != hash_name(message_name<T>())) {
        throw std::runtime_error("Transport::decode<T>: wrong message type arrived");
    }
    T out{};
    raw_decode(buffer.data().first(result.bytes_received), out);
    return out;
}

} // namespace Transport
