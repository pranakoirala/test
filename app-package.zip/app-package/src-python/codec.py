"""App-level message layer for Python -- optional sugar on top of the
generated ITransport.send()/recv(). Unlike buffer.py (near-universal
ownership distinction), everything here IS a project-specific choice:
how names are looked up, how types are decoded.
"""
from __future__ import annotations

from typing import Protocol, TypeVar, runtime_checkable

from transport import ITransport, Status
from buffer import HeapBuffer, ViewBuffer


def hash_name(name: str) -> int:
    """FNV-1a, 32-bit -- same algorithm as the C++/Rust/Java versions,
    so a message tagged 'lidar.Point' hashes to the same type_id
    regardless of which language sent or received it."""
    h = 2166136261
    for byte in name.encode("utf-8"):
        h ^= byte
        h = (h * 16777619) & 0xFFFFFFFF
    return h


@runtime_checkable
class Message(Protocol):
    """Duck-typed -- Python doesn't need a base class or trait the way
    Rust/Java do. Any object with these three things works."""
    name: str

    def encode(self) -> bytes: ...

    @classmethod
    def decode(cls, data: bytes) -> "Message": ...


T = TypeVar("T", bound=Message)

DEFAULT_SCRATCH_CAPACITY = 64 * 1024


def send(transport: ITransport, value: Message) -> Status:
    payload = value.encode()
    buffer = HeapBuffer(payload)
    buffer.mutable_header().type_id = hash_name(value.name)
    return transport.send(buffer)


def send_view(transport: ITransport, view: memoryview, name: str) -> Status:
    """Zero-copy: `view` is expected to be a genuine memoryview into
    something like a flatbuffers Builder's own backing array
    (memoryview(builder.Bytes)[builder.Head():]) -- NOT
    builder.Output(), which slices a bytearray and copies. No new
    bytes object is created here at all."""
    buffer = ViewBuffer(view)
    buffer.mutable_header().type_id = hash_name(name)
    return transport.send(buffer)


def recv(transport: ITransport, cls: type[T], scratch_capacity: int = DEFAULT_SCRATCH_CAPACITY):
    """Returns (Status, T | None) -- Python has no Result<T, E>, this is
    the idiomatic equivalent."""
    buffer = HeapBuffer(bytes(scratch_capacity))
    result = transport.recv(buffer)
    if result.status != Status.SUCCESS:
        return result.status, None
    if buffer.header().type_id != hash_name(cls.name):
        return Status.FAILURE, None  # wrong type arrived
    payload = buffer.data()[: result.bytes_received]
    return Status.SUCCESS, cls.decode(payload)
