"""Core: HeapBuffer (owning) and ViewBuffer (borrowing). Hand-written,
not generated -- "owning vs. borrowing" needs different code per
language, but the CONCEPT is near-universal, unlike message-encoding
strategy (codec.py), which is project-specific.
"""
from __future__ import annotations

from transport import BufferHeader, IBuffer


class HeapBuffer(IBuffer):
    """Owns its bytes in a bytearray (naturally resizable in Python --
    no fixed-capacity constraint the way C++'s std::span-backed version
    has)."""

    def __init__(self, data: bytes | bytearray = b""):
        self._header = BufferHeader(type_id=0, size=len(data))
        self._data = bytearray(data)

    def header(self) -> BufferHeader:
        return self._header

    def mutable_header(self) -> BufferHeader:
        return self._header

    def data(self) -> bytes:
        return bytes(self._data)

    def mutable_data(self) -> bytearray:
        return self._data


class ViewBuffer(IBuffer):
    """Wraps an existing buffer-protocol object (a memoryview,
    bytearray, numpy array, ...) WITHOUT copying -- genuinely
    zero-copy. `data()` returns the memoryview itself, not `bytes` --
    a deliberate, documented deviation from IBuffer's `data() -> bytes`
    type hint: converting to `bytes` would copy, defeating the entire
    point. Python doesn't enforce return-type hints at runtime, and
    callers doing read-only byte-level operations (indexing, slicing,
    len()) work identically either way.

    Read-only by design -- mutable_data() raises, mirroring the
    Rust/Java versions' refusal to expose a safe mutable alias over
    borrowed memory. Use HeapBuffer for recv().
    """

    def __init__(self, view: memoryview):
        self._header = BufferHeader(type_id=0, size=len(view))
        self._view = view

    def header(self) -> BufferHeader:
        return self._header

    def mutable_header(self) -> BufferHeader:
        return self._header

    def data(self):  # intentionally returns memoryview, not bytes -- see class docstring
        return self._view

    def mutable_data(self):
        raise NotImplementedError(
            "ViewBuffer is read-only (send-only zero-copy view) -- use HeapBuffer for recv()"
        )
