"""Demonstrates both layers: the mandatory raw ITransport.send()/recv(),
and the optional codec.send()/recv() sugar on top, plus the zero-copy
send_view() path.
"""
from dataclasses import dataclass

from transport import Status
from loopback_transport import LoopbackTransport
from buffer import HeapBuffer, ViewBuffer
import codec


def test_mandatory_minimum():
    transport = LoopbackTransport.create_transport()
    transport.open()

    payload = b"hello"
    buf = HeapBuffer(payload)
    buf.mutable_header().type_id = 42
    assert transport.send(buf) == Status.SUCCESS

    scratch = HeapBuffer(bytes(1024))
    result = transport.recv(scratch)
    assert result.status == Status.SUCCESS
    assert result.bytes_received == 5
    assert scratch.data() == payload
    assert scratch.header().type_id == 42
    print("mandatory minimum (raw send/recv, no codec.py) OK")


@dataclass
class Sensor:
    name = "test.Sensor"
    reading: float

    def encode(self) -> bytes:
        return str(self.reading).encode("utf-8")

    @classmethod
    def decode(cls, data: bytes) -> "Sensor":
        return cls(reading=float(data.decode("utf-8")))


@dataclass
class Wrong:
    name = "test.Wrong"
    x: int

    def encode(self) -> bytes:
        return str(self.x).encode("utf-8")

    @classmethod
    def decode(cls, data: bytes) -> "Wrong":
        return cls(x=int(data.decode("utf-8")))


def test_optional_sugar():
    transport = LoopbackTransport.create_transport()
    transport.open()

    s = Sensor(reading=42.5)
    assert codec.send(transport, s) == Status.SUCCESS

    status, out = codec.recv(transport, Sensor)
    assert status == Status.SUCCESS
    assert out.reading == 42.5
    print(f"optional sugar (codec.send/codec.recv) OK -> {out}")

    codec.send(transport, Sensor(reading=1.0))
    status, out = codec.recv(transport, Wrong)
    assert status == Status.FAILURE
    assert out is None
    print("type-mismatch correctly rejected")


def test_zero_copy_send():
    """The real test: prove send_view() genuinely doesn't copy, using
    a memoryview identity check -- same class of proof as the C++
    pointer-identity check that caught the original bug."""
    transport = LoopbackTransport.create_transport()
    transport.open()

    # Stand-in for a flatbuffers Builder's own backing array.
    backing = bytearray([10, 20, 30])
    view = memoryview(backing)

    # ViewBuffer must be handed the SAME memoryview object, not a copy.
    buf = ViewBuffer(view)
    assert buf.data() is view, "ViewBuffer.data() must return the identical memoryview object"

    status = codec.send_view(transport, view, "fake.FlatBuffer")
    assert status == Status.SUCCESS

    scratch = HeapBuffer(bytes(1024))
    result = transport.recv(scratch)
    assert result.status == Status.SUCCESS
    assert result.bytes_received == 3
    assert scratch.data()[:3] == bytes(backing)
    print("zero-copy send_view() OK -- ViewBuffer.data() returned the IDENTICAL memoryview "
          "object (verified with `is`, not just equality), exact byte match through the transport")


if __name__ == "__main__":
    test_mandatory_minimum()
    test_optional_sugar()
    test_zero_copy_send()
    print("\nAll Python layer tests passed.")
