"""A toy in-process ITransport, mirroring impl/transport/loopback_transport.cpp."""
from __future__ import annotations

from collections import deque

from transport import ITransport, RecvResult, Status


class LoopbackTransport(ITransport):
    """Toy in-process ITransport, purely so examples run standalone.
    Note what's NOT imported here: buffer.py. This class only ever
    touches whatever IBuffer it's handed through header()/data()/
    mutable_header()/mutable_data() -- it never constructs or names
    HeapBuffer/ViewBuffer directly, the same property proven for C++
    with nm/md5sum (Python has no equivalent binary-level proof, but
    the source-level property -- zero references -- is identical and
    checkable by inspection)."""

    def __init__(self):
        self._open = False
        self._queue: deque[tuple[int, bytes]] = deque()

    @staticmethod
    def create_transport() -> "ITransport":
        return LoopbackTransport()

    def configure(self, config):
        return Status.SUCCESS

    def open(self) -> Status:
        self._open = True
        return Status.SUCCESS

    def close(self) -> Status:
        self._open = False
        return Status.SUCCESS

    def is_open(self) -> bool:
        return self._open

    def send(self, buffer: "object") -> Status:
        if not self._open:
            return Status.FAILURE
        # bytes(...) here copies into this transport's OWN internal
        # queue storage -- that's this (toy) transport's own
        # implementation choice for holding multiple pending messages,
        # not something the app had to do. A real transport writing
        # straight to a socket wouldn't need this copy at all; it
        # could write directly from buffer.data(), memoryview included.
        self._queue.append((buffer.header().type_id, bytes(buffer.data())))
        return Status.SUCCESS

    def recv(self, buffer: "object") -> RecvResult:
        if not self._queue:
            return RecvResult(status=Status.TIMEOUT, bytes_received=0)
        type_id, payload = self._queue.popleft()
        dst = buffer.mutable_data()
        dst[: len(payload)] = payload
        del dst[len(payload):]  # trim any leftover capacity, mirrors C++'s exact-length semantics
        buffer.mutable_header().type_id = type_id
        return RecvResult(status=Status.SUCCESS, bytes_received=len(payload))
