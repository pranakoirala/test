//! A toy ITransport implementation, mirroring impl/transport/loopback_transport.cpp.
//! NOT compiled in this sandbox (no rustc available) -- structurally
//! checked only (brace/paren balance). Written carefully against the
//! generated transport.rs trait signatures, but treat this as
//! unverified until you compile it yourself. HeapBuffer/ViewBuffer
//! now live in buffer.rs (promoted to core -- see there for why).

use std::collections::VecDeque;
use crate::transport::{IBuffer, ITransport, RecvResult, Status};

struct QueuedMessage {
    type_id: u32,
    payload: Vec<u8>,
}

/// Toy in-process ITransport, purely so examples run standalone.
pub struct LoopbackTransport {
    is_open: bool,
    queue: VecDeque<QueuedMessage>,
}

impl LoopbackTransport {
    pub fn new() -> Self {
        LoopbackTransport { is_open: false, queue: VecDeque::new() }
    }
}

impl ITransport for LoopbackTransport {
    fn create_transport() -> Box<dyn ITransport> where Self: Sized {
        Box::new(LoopbackTransport::new())
    }

    fn configure(&mut self, _config: &crate::transport::Config) -> Status {
        Status::Success
    }

    fn open(&mut self) -> Status {
        self.is_open = true;
        Status::Success
    }

    fn close(&mut self) -> Status {
        self.is_open = false;
        Status::Success
    }

    fn is_open(&self) -> bool {
        self.is_open
    }

    fn send(&mut self, buffer: &dyn IBuffer) -> Status {
        if !self.is_open {
            return Status::Failure;
        }
        self.queue.push_back(QueuedMessage {
            type_id: buffer.header().type_id,
            payload: buffer.data().to_vec(),
        });
        Status::Success
    }

    fn recv(&mut self, buffer: &mut dyn IBuffer) -> RecvResult {
        let Some(front) = self.queue.pop_front() else {
            return RecvResult { status: Status::Timeout, bytes_received: 0 };
        };
        let dst = buffer.mutable_data();
        if dst.len() < front.payload.len() {
            return RecvResult { status: Status::Failure, bytes_received: 0 };
        }
        dst[..front.payload.len()].copy_from_slice(&front.payload);
        buffer.mutable_header().type_id = front.type_id;
        RecvResult { status: Status::Success, bytes_received: front.payload.len() as u64 }
    }
}

