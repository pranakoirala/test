//! App-level message layer for Rust -- optional sugar on top of the
//! generated ITransport::send()/recv(), same relationship as C++'s
//! codec.hpp. Nothing here is required: an app can always construct a
//! HeapBuffer directly and call
//! transport.send(&buffer)/transport.recv(&mut buffer) itself.
//!
//! NOT compiled in this sandbox (no rustc available) -- see the note
//! in loopback_transport.rs.

use crate::transport::{ITransport, Status};
use crate::buffer::{HeapBuffer, ViewBuffer};

pub const DEFAULT_SCRATCH_CAPACITY: usize = 64 * 1024;

/// FNV-1a, 32-bit -- same algorithm as the C++/Python versions, so a
/// message tagged "lidar.Point" hashes to the same type_id regardless
/// of which language sent or received it.
pub const fn hash_name(name: &str) -> u32 {
    let bytes = name.as_bytes();
    let mut h: u32 = 2166136261;
    let mut i = 0;
    while i < bytes.len() {
        h ^= bytes[i] as u32;
        h = h.wrapping_mul(16777619);
        i += 1;
    }
    h
}

/// A trait, not duck-typing -- more idiomatic Rust than trying to
/// mirror C++'s ProtobufLike/HasKnownName concepts structurally. A
/// prost-generated protobuf type implements this by delegating to its
/// own Message trait internally; a plain struct implements it with a
/// direct memory copy or manual (de)serialization.
pub trait Message: Sized {
    const NAME: &'static str;
    fn encode(&self) -> Vec<u8>;
    fn decode(bytes: &[u8]) -> Self;
}

pub fn send<T: Message>(transport: &mut dyn ITransport, value: &T) -> Status {
    let mut buffer = HeapBuffer::new(value.encode());
    buffer.mutable_header().type_id = hash_name(T::NAME);
    transport.send(&buffer)
}

/// Zero-copy send: `bytes` is expected to be a genuinely borrowed
/// slice from something like a `flatbuffers::FlatBufferBuilder`'s own
/// `finished_data()` (the real crate's zero-copy accessor -- not
/// modeled here as a full FlatBuilderLike trait the way C++ uses a
/// duck-typed concept, since there's no real `flatbuffers` crate
/// dependency in this environment to bridge to). No allocation, no
/// copy: `ViewBuffer` just borrows `bytes` for the duration of the
/// send() call.
///
/// This is the fix for a real gap: earlier versions of this file only
/// had `send<T: Message>()`, which always calls `T::encode(&self) ->
/// Vec<u8>` -- unconditionally owned, no zero-copy path existed at
/// all (unlike the C++ version, this never claimed otherwise, but the
/// optimization was simply missing).
pub fn send_view(transport: &mut dyn ITransport, bytes: &[u8], name: &str) -> Status {
    let mut buffer = ViewBuffer::new(bytes);
    buffer.mutable_header().type_id = hash_name(name);
    transport.send(&buffer)
}

/// scratch_capacity has the same fixed-internal-default rationale as
/// the C++ version -- IBuffer has no grow capability, and Rust's
/// mutable_data() returning &mut [u8] (a fixed-length slice) means the
/// same constraint applies here, unlike Python's naturally-resizable
/// bytearray.
pub fn recv<T: Message>(transport: &mut dyn ITransport, scratch_capacity: usize) -> Result<T, Status> {
    let mut scratch = HeapBuffer::with_capacity(scratch_capacity);
    let result = transport.recv(&mut scratch);
    if result.status != Status::Success {
        return Err(result.status);
    }
    if scratch.header().type_id != hash_name(T::NAME) {
        return Err(Status::Failure); // wrong type arrived
    }
    let n = result.bytes_received as usize;
    Ok(T::decode(&scratch.data()[..n]))
}

/// Convenience: recv() with the default capacity, so the common call
/// site is just `recv_default::<LidarPoint>(&mut *transport)`.
pub fn recv_default<T: Message>(transport: &mut dyn ITransport) -> Result<T, Status> {
    recv(transport, DEFAULT_SCRATCH_CAPACITY)
}
