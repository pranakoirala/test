//! Core: HeapBuffer (owning) and ViewBuffer (borrowing). Hand-written,
//! not generated -- "owning vs. borrowing" needs a different code
//! shape per language (Rust needs an explicit lifetime parameter on
//! the borrowing variant; C++ doesn't), but the CONCEPT is near-
//! universal, unlike message-encoding strategy (codec.rs), which is
//! project-specific.
//!
//! NOT compiled in this sandbox (no rustc available) -- treat as a
//! careful draft, not verified code.

use crate::transport::{BufferHeader, IBuffer};

pub struct HeapBuffer {
    header: BufferHeader,
    bytes: Vec<u8>,
}

impl HeapBuffer {
    pub fn new(bytes: Vec<u8>) -> Self {
        let size = bytes.len() as u64;
        HeapBuffer { header: BufferHeader { type_id: 0, size }, bytes }
    }

    pub fn with_capacity(capacity: usize) -> Self {
        HeapBuffer {
            header: BufferHeader { type_id: 0, size: capacity as u64 },
            bytes: vec![0u8; capacity],
        }
    }
}

impl IBuffer for HeapBuffer {
    fn header(&self) -> &BufferHeader { &self.header }
    fn mutable_header(&mut self) -> &mut BufferHeader { &mut self.header }
    fn data(&self) -> &[u8] { &self.bytes }
    fn mutable_data(&mut self) -> &mut [u8] { &mut self.bytes }
}

/// Borrows an existing byte slice instead of owning it -- genuinely
/// zero-copy. Needs an explicit lifetime, unlike HeapBuffer: the
/// borrow checker has to track that `bytes` doesn't outlive whatever
/// it came from. This isn't a renamed copy of HeapBuffer -- it's a
/// structurally different type, which is the point: "owning vs.
/// borrowing" genuinely needs different code per language.
///
/// Read-only by design: mutable_data() panics rather than attempting
/// an unsafe cast from a shared borrow to a mutable one, which would
/// be real undefined behavior in Rust if anything else holds a
/// reference to the same memory. This type is for the send-only
/// zero-copy path; recv() should use HeapBuffer instead.
pub struct ViewBuffer<'a> {
    header: BufferHeader,
    bytes: &'a [u8],
}

impl<'a> ViewBuffer<'a> {
    pub fn new(bytes: &'a [u8]) -> Self {
        let size = bytes.len() as u64;
        ViewBuffer { header: BufferHeader { type_id: 0, size }, bytes }
    }
}

impl<'a> IBuffer for ViewBuffer<'a> {
    fn header(&self) -> &BufferHeader { &self.header }
    fn mutable_header(&mut self) -> &mut BufferHeader { &mut self.header }
    fn data(&self) -> &[u8] { self.bytes }
    fn mutable_data(&mut self) -> &mut [u8] {
        panic!("ViewBuffer is read-only (send-only zero-copy view) -- use HeapBuffer for recv()")
    }
}
