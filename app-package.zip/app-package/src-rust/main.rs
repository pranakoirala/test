//! Demonstrates both layers: the mandatory raw ITransport::send()/recv(),
//! and the optional codec::send()/recv() sugar on top.
//! NOT compiled in this sandbox -- see note in loopback_transport.rs.

mod transport; // generated
mod buffer;
mod loopback_transport;
mod codec;

use transport::{ITransport, Status};
use buffer::HeapBuffer;
use loopback_transport::LoopbackTransport;
use codec::Message;

// -----------------------------------------------------------------
// Mandatory minimum: create_transport(), then ->send()/->recv() with a
// raw IBuffer. No codec.rs involved at all.
// -----------------------------------------------------------------
fn test_mandatory_minimum() {
    let mut transport = LoopbackTransport::create_transport();
    transport.open();

    let payload = b"hello".to_vec();
    let mut buf = HeapBuffer::new(payload.clone());
    buf.mutable_header().type_id = 42;
    assert_eq!(transport.send(&buf), Status::Success);

    let mut scratch = HeapBuffer::with_capacity(1024);
    let result = transport.recv(&mut scratch);
    assert_eq!(result.status, Status::Success);
    assert_eq!(result.bytes_received, 5);
    assert_eq!(&scratch.data()[..5], &payload[..]);
    assert_eq!(scratch.header().type_id, 42);
    println!("mandatory minimum (raw send/recv, no codec.rs) OK");
}

// -----------------------------------------------------------------
// Optional sugar: codec::send()/codec::recv().
// -----------------------------------------------------------------
struct Sensor {
    reading: f64,
}

impl Message for Sensor {
    const NAME: &'static str = "test.Sensor";

    fn encode(&self) -> Vec<u8> {
        self.reading.to_string().into_bytes()
    }

    fn decode(bytes: &[u8]) -> Self {
        Sensor { reading: std::str::from_utf8(bytes).unwrap().parse().unwrap() }
    }
}

struct Wrong {
    x: i32,
}

impl Message for Wrong {
    const NAME: &'static str = "test.Wrong";
    fn encode(&self) -> Vec<u8> {
        self.x.to_string().into_bytes()
    }
    fn decode(bytes: &[u8]) -> Self {
        Wrong { x: std::str::from_utf8(bytes).unwrap().parse().unwrap() }
    }
}

fn test_optional_sugar() {
    let mut transport = LoopbackTransport::create_transport();
    transport.open();

    let s = Sensor { reading: 42.5 };
    assert_eq!(codec::send(&mut *transport, &s), Status::Success);

    let out: Sensor = codec::recv_default(&mut *transport).unwrap();
    assert_eq!(out.reading, 42.5);
    println!("optional sugar (codec::send/codec::recv) OK -> reading={}", out.reading);

    // Type-mismatch safety.
    codec::send(&mut *transport, &Sensor { reading: 1.0 });
    let result: Result<Wrong, Status> = codec::recv_default(&mut *transport);
    assert_eq!(result.unwrap_err(), Status::Failure);
    println!("type-mismatch correctly rejected");
}

fn main() {
    test_mandatory_minimum();
    test_optional_sugar();
    test_zero_copy_send();
    println!("\nAll Rust layer tests passed (structurally -- not compiled in this sandbox).");
}

// -----------------------------------------------------------------
// Zero-copy: send_view() borrows bytes instead of owning them --
// no allocation, no copy, unlike send<T: Message>() which always
// calls T::encode() -> Vec<u8> (necessarily owned).
// -----------------------------------------------------------------
fn test_zero_copy_send() {
    let mut transport = LoopbackTransport::create_transport();
    transport.open();

    // Stand-in for a real flatbuffers::FlatBufferBuilder's own buffer
    // (e.g. via builder.finished_data()) -- send_view() borrows this
    // directly, never copies it.
    let builder_bytes: Vec<u8> = vec![10, 20, 30];
    assert_eq!(codec::send_view(&mut *transport, &builder_bytes, "fake.FlatBuffer"), Status::Success);

    let mut scratch = HeapBuffer::with_capacity(1024);
    let result = transport.recv(&mut scratch);
    assert_eq!(result.status, Status::Success);
    assert_eq!(result.bytes_received, 3);
    assert_eq!(&scratch.data()[..3], &builder_bytes[..]);
    println!("zero-copy send_view() OK -- exact byte match, no allocation in the send path");
}
