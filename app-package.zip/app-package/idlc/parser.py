"""Recursive-descent parser: tokens -> Typed AST.

Grammar (informal, subset actually needed by transport.idl):

    translation_unit  ::= annotation_decl* module_decl
    annotation_decl   ::= '@annotation' ID '{' '}' ';'
    module_decl       ::= 'module' ID '{' member* '}' ';'
    member            ::= enum_decl | typedef_decl | interface_decl
    enum_decl         ::= 'enum' ID '{' ID (',' ID)* '}' ';'
    typedef_decl      ::= 'typedef' type_ref ID ';'
    interface_decl    ::= annotation* 'local' 'interface' ID '{' operation* '}' ';'
    operation         ::= annotation* type_ref ID '(' param_list? ')' ';'
    param             ::= annotation* ('in'|'inout'|'out') type_ref ID
    type_ref          ::= ID ('<' type_ref (',' type_ref)* '>')?
    annotation        ::= '@' ID
"""

from __future__ import annotations

from .ast_nodes import (
    AnnotationDecl, EnumDecl, InterfaceDecl, Module, Operation, Param,
    StructDecl, StructField, TranslationUnit, TypeRef, TypedefDecl,
)
from .tokenizer import Token, tokenize

_DIRECTIONS = {"in", "inout", "out"}


class ParseError(SyntaxError):
    pass


class Parser:
    def __init__(self, tokens: list[Token]):
        self.tokens = tokens
        self.pos = 0

    # -- token helpers ----------------------------------------------
    def peek(self) -> Token:
        return self.tokens[self.pos]

    def advance(self) -> Token:
        tok = self.tokens[self.pos]
        self.pos += 1
        return tok

    def expect(self, value: str) -> Token:
        tok = self.peek()
        if tok.value != value:
            raise ParseError(
                f"line {tok.line}: expected {value!r}, got {tok.value!r}"
            )
        return self.advance()

    def at(self, value: str) -> bool:
        return self.peek().value == value

    # -- grammar rules ------------------------------------------------
    def parse_translation_unit(self) -> TranslationUnit:
        annotations = []
        while self.at("@") and self._peek_ahead_is("annotation"):
            annotations.append(self.parse_annotation_decl())
        module = self.parse_module()
        return TranslationUnit(annotations=annotations, module=module)

    def _peek_ahead_is(self, keyword: str) -> bool:
        return self.tokens[self.pos + 1].value == keyword

    def parse_annotation_decl(self) -> AnnotationDecl:
        self.expect("@")
        self.expect("annotation")
        name = self.advance().value
        self.expect("{")
        self.expect("}")
        self.expect(";")
        return AnnotationDecl(name=name)

    def parse_module(self) -> Module:
        self.expect("module")
        name = self.advance().value
        self.expect("{")
        mod = Module(name=name)
        while not self.at("}"):
            if self.at("enum"):
                mod.enums.append(self.parse_enum())
            elif self.at("struct"):
                mod.structs.append(self.parse_struct())
            elif self.at("typedef"):
                mod.typedefs.append(self.parse_typedef())
            elif self.at("@") or self.at("local"):
                mod.interfaces.append(self.parse_interface())
            else:
                tok = self.peek()
                raise ParseError(f"line {tok.line}: unexpected token {tok.value!r} in module body")
        self.expect("}")
        self.expect(";")
        return mod

    def parse_enum(self) -> EnumDecl:
        self.expect("enum")
        name = self.advance().value
        self.expect("{")
        values = [self.advance().value]
        while self.at(","):
            self.advance()
            values.append(self.advance().value)
        self.expect("}")
        self.expect(";")
        return EnumDecl(name=name, values=values)

    def parse_struct(self) -> StructDecl:
        # struct NAME { type_ref field_name; type_ref field_name; ... };
        # Plain data fields only -- no operations, no `local` keyword.
        # Distinct from `interface`, which generators turn into a
        # virtual base class / trait; a struct is a plain value type.
        self.expect("struct")
        name = self.advance().value
        self.expect("{")
        fields = []
        while not self.at("}"):
            field_type = self.parse_type_ref()
            field_name = self.advance().value
            self.expect(";")
            fields.append(StructField(type=field_type, name=field_name))
        self.expect("}")
        self.expect(";")
        return StructDecl(name=name, fields=fields)

    def parse_typedef(self) -> TypedefDecl:
        self.expect("typedef")
        type_ref = self.parse_type_ref()
        name = self.advance().value
        self.expect(";")
        return TypedefDecl(name=name, underlying=type_ref)

    # IDL base-type keywords that combine into multi-token type names,
    # e.g. `unsigned long long`.
    _INT_MODIFIERS = {"unsigned", "signed", "long", "short"}
    _INT_CONTINUATIONS = {"long", "short", "int"}

    def parse_type_ref(self) -> TypeRef:
        parts = [self.advance().value]
        if parts[0] in self._INT_MODIFIERS:
            while self.peek().value in self._INT_CONTINUATIONS:
                parts.append(self.advance().value)
        name = " ".join(parts)
        args: list[TypeRef] = []
        if self.at("<"):
            self.advance()
            args.append(self.parse_type_ref())
            while self.at(","):
                self.advance()
                args.append(self.parse_type_ref())
            self.expect(">")
        return TypeRef(name=name, args=args)

    def parse_annotations(self) -> list[str]:
        names = []
        while self.at("@"):
            self.advance()
            names.append(self.advance().value)
        return names

    def parse_interface(self) -> InterfaceDecl:
        annotations = self.parse_annotations()
        self.expect("local")
        self.expect("interface")
        name = self.advance().value
        self.expect("{")
        ops = []
        while not self.at("}"):
            ops.append(self.parse_operation())
        self.expect("}")
        self.expect(";")
        return InterfaceDecl(name=name, is_local=True, operations=ops, annotations=annotations)

    def parse_operation(self) -> Operation:
        annotations = self.parse_annotations()
        return_type = self.parse_type_ref()
        name = self.advance().value
        self.expect("(")
        params = []
        if not self.at(")"):
            params.append(self.parse_param())
            while self.at(","):
                self.advance()
                params.append(self.parse_param())
        self.expect(")")
        self.expect(";")
        return Operation(name=name, return_type=return_type, params=params, annotations=annotations)

    def parse_param(self) -> Param:
        annotations = self.parse_annotations()
        direction_tok = self.advance()
        if direction_tok.value not in _DIRECTIONS:
            raise ParseError(
                f"line {direction_tok.line}: expected in/inout/out, got {direction_tok.value!r}"
            )
        type_ref = self.parse_type_ref()
        name = self.advance().value
        return Param(direction=direction_tok.value, type=type_ref, name=name, annotations=annotations)


def parse(source: str) -> TranslationUnit:
    return Parser(tokenize(source)).parse_translation_unit()
