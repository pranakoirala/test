"""Java backend: SemanticModel -> Java syntax.

Java has no type-alias mechanism, so unlike Rust's `pub type Config = ...`
or Python's `Config = Dict[str, str]`, an 'alias' ResolvedType is erased
to its underlying type at every use site here -- there is no Config.java
class generated, callers just see java.util.Map<String, String> directly.

Java also has no reference/value distinction to encode (objects are
always reference types) -- the closest analog to `@const_ref` is the
`final` parameter modifier, which only prevents reassignment, not deep
mutation. Applied anyway since it's the idiomatic signal.
"""

from __future__ import annotations

from dataclasses import dataclass

from .semantics import ResolvedOperation, ResolvedParam, ResolvedStructField, ResolvedType, SemanticModel

_PRIMITIVE = {"string": "String", "boolean": "boolean"}

# Real CORBA "IDL to Java" mapping convention: Java has no unsigned
# integer primitives, so unsigned IDL types map to the Java primitive
# of the same bit width, with the app responsible for treating the top
# bit as magnitude rather than sign where it matters (e.g.
# Integer.toUnsignedLong()). Not our invention -- this is how real IDL
# Java bindings have always handled it.
_NUMERIC = {
    "short": "short",
    "unsigned short": "int",
    "long": "int",
    "unsigned long": "int",
    "long long": "long",
    "unsigned long long": "long",
    "float": "float",
    "double": "double",
}


@dataclass
class JavaMapper:
    model: SemanticModel

    def __post_init__(self) -> None:
        self._alias_underlying = {a.name: a.underlying for a in self.model.alias_typedefs}

    def java_type(self, t: ResolvedType) -> str:
        if t.kind == "void":
            return "void"
        if t.kind == "numeric":
            return _NUMERIC[t.name]
        if t.kind == "primitive":
            return _PRIMITIVE[t.name]
        if t.kind == "byte_view":
            # Same underlying type either way -- ByteBuffer has no separate
            # read-only *type*, only a read-only *instance* flag
            # (buf.asReadOnlyBuffer()). Mutability is documented, not enforced.
            return "ByteBuffer"
        if t.kind == "map":
            return f"Map<{self.java_type(t.key)}, {self.java_type(t.value)}>"
        if t.kind == "alias":
            # Erase to the underlying type -- no Java type alias exists.
            return self.java_type(self._alias_underlying[t.name])
        if t.kind in ("enum_ref", "interface_ref", "struct_ref"):
            return t.name
        raise ValueError(f"unhandled ResolvedType kind: {t.kind}")

    def java_param(self, p: ResolvedParam) -> str:
        base = self.java_type(p.type)
        prefix = "final " if (p.by_ref and not p.ref_mutable) else ""
        return f"{prefix}{base} {p.name}"

    def java_field_param(self, f: ResolvedStructField) -> str:
        # Struct constructor params: no by-ref/final concept here, just
        # plain typed params -- distinct from java_param since
        # ResolvedStructField has no direction/const_ref to consult.
        return f"{self.java_type(f.type)} {f.name}"

    def java_return(self, op: ResolvedOperation) -> str:
        return self.java_type(op.return_type)

    def required_imports(self) -> list[str]:
        needed: set[str] = set()

        def scan(t: ResolvedType) -> None:
            if t.kind == "byte_view":
                needed.add("java.nio.ByteBuffer")
            elif t.kind == "map":
                needed.add("java.util.Map")
                scan(t.key)
                scan(t.value)
            elif t.kind == "alias":
                scan(self._alias_underlying[t.name])

        for iface in self.model.interfaces:
            for op in iface.operations:
                scan(op.return_type)
                for p in op.params:
                    scan(p.type)
        return sorted(needed)
