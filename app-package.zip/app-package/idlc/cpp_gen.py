"""C++ backend: SemanticModel -> C++ syntax.

Thin by design -- every actual semantic decision (numeric widths,
byte-view mutability, ref-vs-value, alias resolution) already happened
in semantics.py. This file only knows how to spell each ResolvedType
kind in C++ and which headers each spelling requires.
"""

from __future__ import annotations

from dataclasses import dataclass

from .semantics import ResolvedOperation, ResolvedParam, ResolvedType, SemanticModel

_PRIMITIVE = {"string": "std::string", "boolean": "bool"}

# Fixed-width mappings matching the real OMG IDL 4.2 integer/float
# ranges (Table 7-13) exactly -- not platform-native types like
# `long`/`size_t`, whose actual width varies by platform.
_NUMERIC = {
    "short": "std::int16_t",
    "unsigned short": "std::uint16_t",
    "long": "std::int32_t",
    "unsigned long": "std::uint32_t",
    "long long": "std::int64_t",
    "unsigned long long": "std::uint64_t",
    "float": "float",
    "double": "double",
}

_BASELINE_INCLUDES = {"<memory>"}


@dataclass
class CppMapper:
    model: SemanticModel

    def cpp_type(self, t: ResolvedType) -> str:
        if t.kind == "void":
            return "void"
        if t.kind == "numeric":
            return _NUMERIC[t.name]
        if t.kind == "primitive":
            return _PRIMITIVE[t.name]
        if t.kind == "byte_view":
            inner = "std::uint8_t" if t.mutable else "const std::uint8_t"
            return f"std::span<{inner}>"
        if t.kind == "map":
            return f"std::map<{self.cpp_type(t.key)}, {self.cpp_type(t.value)}>"
        if t.kind in ("alias", "enum_ref", "interface_ref", "struct_ref"):
            return t.name
        raise ValueError(f"unhandled ResolvedType kind: {t.kind}")

    def cpp_param(self, p: ResolvedParam) -> str:
        base = self.cpp_type(p.type)
        if p.by_ref:
            base = f"{base}&" if p.ref_mutable else f"const {base}&"
        return f"{base} {p.name}"

    def cpp_return(self, op: ResolvedOperation) -> str:
        t = op.return_type
        if t.kind == "interface_ref":
            # Raw, owning pointer -- caller takes ownership and is
            # responsible for eventually calling `delete`. Deliberately
            # not std::unique_ptr/std::shared_ptr: a raw pointer converts
            # implicitly into whichever owning type the caller actually
            # wants, whereas a smart pointer return would force one
            # specific choice on every caller.
            return f"{t.name}*"
        if t.kind == "struct_ref":
            if t.view == "readonly_view":
                return f"const {t.name}&"
            if t.view == "mutable_view":
                return f"{t.name}&"
            return t.name  # plain by-value return, e.g. RecvResult
        return self.cpp_type(t)

    def required_includes(self) -> list[str]:
        needed: set[str] = set(_BASELINE_INCLUDES)

        def scan(t: ResolvedType) -> None:
            if t.kind == "numeric" and t.name not in ("float", "double"):
                needed.add("<cstdint>")
            elif t.kind == "primitive" and t.name == "string":
                needed.add("<string>")
            elif t.kind == "byte_view":
                needed.add("<span>")
                needed.add("<cstdint>")
            elif t.kind == "map":
                needed.add("<map>")
                scan(t.key)
                scan(t.value)

        for alias in self.model.alias_typedefs:
            scan(alias.underlying)
        for struct in self.model.structs:
            for f in struct.fields:
                scan(f.type)
        for iface in self.model.interfaces:
            for op in iface.operations:
                scan(op.return_type)
                for p in op.params:
                    scan(p.type)
        return sorted(needed, key=lambda h: h.strip("<>"))
